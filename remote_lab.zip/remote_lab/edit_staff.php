<?php
session_start();
include("dbconnect.php");
extract($_REQUEST);
$msg="";

$qry=mysqli_query($connect,"select * from vir_staff where id=$sid");
$row=mysqli_fetch_array($qry);

if(isset($btn))
{
	$ins=mysqli_query($connect,"update vir_staff set name='$name',uname='$uname',mobile='$mobile',email='$email',stype='$stype' where id=$sid");
	if($ins)
	{
	?>
	<script language="javascript">
	alert("Updated Sucessfully");
	window.location.href="add_staff.php";
	</script>
	<?php
	}
	
}
if(isset($btn2))
{
$fn="";
	if($_FILES['file']['name']!="")
	{
	$fn="S".$sid.$_FILES['file']['name'];
	move_uploaded_file($_FILES['file']['tmp_name'],"photo/".$fn);
	$ins=mysqli_query($connect,"update vir_staff set photo='$fn' where id=$sid");
	
	?>
	<script language="javascript">
	alert("Updated Sucessfully");
	window.location.href="add_staff.php";
	</script>
	<?php
	
	}
}
////////////////////////
if($act=="del")
{
mysqli_query($connect,"delete from vir_student where id=$did");
	?>
	<script language="javascript">
	alert("Deleted Sucessfully");
	window.location.href="admin.php";
	</script>
	<?php
}
?>
<html>
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Virtual Lab</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- site icon -->
      <link rel="icon" href="images/fevicon.png" type="image/png" />
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css" />
      <!-- site css -->
      <link rel="stylesheet" href="style.css" />
      <!-- responsive css -->
      <link rel="stylesheet" href="css/responsive.css" />
      <!-- color css -->
      <link rel="stylesheet" href="css/colors.css" />
      <!-- select bootstrap -->
      <link rel="stylesheet" href="css/bootstrap-select.css" />
      <!-- scrollbar css -->
      <link rel="stylesheet" href="css/perfect-scrollbar.css" />
      <!-- custom css -->
      <link rel="stylesheet" href="css/custom.css" />
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->
<script language="javascript">
function del()
{
	if(!confirm("Are you sure want to Delete?"))
	{
	return false;
	}
	return true;
}
            function validate()
            {
			  
                if (document.form1.name.value == "")
                {
                    alert("Enter the Name");
                    document.form1.name.focus();
                    return false;
                }
				var name=document.form1.name;
			    var letters = /^[A-Za-z. ]+$/;  
				if(name.value.match(letters))  
				{  
				//return true;  
				}  
				else  
				{  
				alert('Username must have alphabet characters only');  
				document.form1.name.select();  
				return false;  
				}
				if (document.form1.uname.value == "")
                {
                    alert("Enter the Staff ID");
                    document.form1.uname.focus();
                    return false;
                }
				if (document.form1.mobile.value == "")
                {
                    alert("Enter the Mobile No.");
                    document.form1.mobile.focus();
                    return false;
                }
				if (isNaN(document.form1.mobile.value))
                {
                    alert("Invalid Mobile No.");
                    document.form1.mobile.select();
                    return false;
                }
				if (document.form1.mobile.value.length != 10)
                {
                    alert("10 digists only allowed!!");
                    document.form1.mobile.select();
                    return false;
                }
                if (document.form1.email.value == "")
                {
                    alert("Enter the E-mail");
                    document.form1.email.focus();
                    return false;
                }
				if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(document.form1.email.value))  
				  {  
					//return (true)  
				  }  
				  else
				  {
					alert("You have entered an invalid email address!");
					document.form1.email.select();
					return false; 
				  }
               if (document.form1.stype.selectedIndex == 0)
                {
                    alert("Select the Type");
                    document.form1.stype.focus();
                    return false;
                }
				
				return true;
				}
				</script>
				
   </head>
   <body class="dashboard dashboard_1">
      <div class="full_container">
         <div class="inner_container">
            <!-- Sidebar  -->
            <nav id="sidebar">
               <div class="sidebar_blog_1">
                  <div class="sidebar-header">
                     <div class="logo_section">
                        <a href=""><img class="logo_icon img-responsive" src="images/logo/logo_icon.png" alt="#" /></a>
                     </div>
                  </div>
                  <div class="sidebar_user_info">
                     <div class="icon_setting"></div>
                     <div class="user_profle_side">
                        <div class="user_img"><img class="img-responsive" src="images/logo/logo_icon.png" alt="#" /></div>
                        <div class="user_info">
                           <h6>Admin</h6>
                           <p><span class="online_animation"></span> Online</p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="sidebar_blog_2">
                  <h4>General</h4>
                  <ul class="list-unstyled components">
				  	<li><a href="admin.php"><i class="fa fa-dashboard yellow_color"></i> <span>Dashboard</span></a></li>
                     <!--<li class="active">
                        <a href="#dashboard" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-dashboard yellow_color"></i> <span>Dashboard</span></a>
                        <ul class="collapse list-unstyled" id="dashboard">
                           <li>
                              <a href="dashboard.html">> <span>Default Dashboard</span></a>
                           </li>
                           <li>
                              <a href="dashboard_2.html">> <span>Dashboard style 2</span></a>
                           </li>
                        </ul>
                     </li>-->
                     <li><a href="view_lab.php"><i class="fa fa-clock-o orange_color"></i> <span>Lab Time</span></a></li>
					 <li><a href="view_program.php"><i class="fa fa-diamond purple_color"></i> <span>Programs</span></a></li>
                     <!--<li>
                        <a href="#element" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-diamond purple_color"></i> <span>Programs</span></a>
                        <ul class="collapse list-unstyled" id="element">
                           <li><a href="general_elements.html">> <span>General Elements</span></a></li>
                           <li><a href="media_gallery.html">> <span>Media Gallery</span></a></li>
                           <li><a href="icons.html">> <span>Icons</span></a></li>
                           <li><a href="invoice.html">> <span>Invoice</span></a></li>
                        </ul>
                     </li>-->
                     <li><a href="view_test.php"><i class="fa fa-table purple_color2"></i> <span>Test</span></a></li>
                     <li>
                        <!--<a href="#apps" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-object-group blue2_color"></i> <span>Apps</span></a>
                        <ul class="collapse list-unstyled" id="apps">
                           <li><a href="email.html">> <span>Email</span></a></li>
                           <li><a href="calendar.html">> <span>Calendar</span></a></li>
                           <li><a href="media_gallery.html">> <span>Media Gallery</span></a></li>
                        </ul>-->
                     </li>
                     <li><a href="logout.php"><i class="fa fa-briefcase blue1_color"></i> <span>Logout</span></a></li>
                     <!--<li>
                        <a href="contact.html">
                        <i class="fa fa-paper-plane red_color"></i> <span>Contact</span></a>
                     </li>-->
                     <!--<li class="active">
                        <a href="#additional_page" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-clone yellow_color"></i> <span>Additional Pages</span></a>
                        <ul class="collapse list-unstyled" id="additional_page">
                           <li>
                              <a href="profile.html">> <span>Profile</span></a>
                           </li>
                           <li>
                              <a href="project.html">> <span>Projects</span></a>
                           </li>
                           <li>
                              <a href="login.html">> <span>Login</span></a>
                           </li>
                           <li>
                              <a href="404_error.html">> <span>404 Error</span></a>
                           </li>
                        </ul>
                     </li>
                     <li><a href="map.html"><i class="fa fa-map purple_color2"></i> <span>Map</span></a></li>
                     <li><a href="charts.html"><i class="fa fa-bar-chart-o green_color"></i> <span>Charts</span></a></li>
                     <li><a href="settings.html"><i class="fa fa-cog yellow_color"></i> <span>Settings</span></a></li>-->
                  </ul>
               </div>
            </nav>
            <!-- end sidebar -->
            <!-- right content -->
            <div id="content">
               <!-- topbar -->
               <div class="topbar">
                  <nav class="navbar navbar-expand-lg navbar-light">
                     <div class="full">
                        <button type="button" id="sidebarCollapse" class="sidebar_toggle"><i class="fa fa-bars"></i></button>
                        <div class="logo_section">
                           <a href="index.html"><img class="img-responsive" src="images/logo/logo.png" alt="#" /></a>
                        </div>
                        <div class="right_topbar">
                           <div class="icon_info">
                              
                              <ul class="user_profile_dd">
                                 <li>
                                    <a class="dropdown-toggle" data-toggle="dropdown"><img class="img-responsive rounded-circle" src="images/logo/logo_icon.png" alt="#" /><span class="name_user">Admin</span></a>
                                    <div class="dropdown-menu">
                                       
                                       <a class="dropdown-item" href="logout.php"><span>Log Out</span> <i class="fa fa-sign-out"></i></a>
                                    </div>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </nav>
               </div>
               <!-- end topbar -->
               <!-- dashboard inner -->
               <div class="midde_cont">
                  <div class="container-fluid">
                     <div class="row column_title">
                        <div class="col-md-12">
                           <div class="page_title">
                              <h2>Dashboard</h2>
                           </div>
                        </div>
                     </div>
                     <div class="row column1">
                        <div class="col-md-6 col-lg-3">
                           <div class="full counter_section margin_bottom_30">
                              <div class="couter_icon">
                                 <div> 
                                    <i class="fa fa-user yellow_color"></i>
                                 </div>
                              </div>
                              <div class="counter_no">
                                 <div>
                                    
                                    <p class="head_couter"><a href="admin.php">Students</a></p>
                                 </div>
                              </div>
                           </div>
                        </div>
						<div class="col-md-6 col-lg-3">
                           <div class="full counter_section margin_bottom_30">
                              <div class="couter_icon">
                                 <div> 
                                    <i class="fa fa-user yellow_color"></i>
                                 </div>
                              </div>
                              <div class="counter_no">
                                 <div>
                                    
                                    <p class="head_couter"><a href="add_staff.php">Staff</a></p>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-6 col-lg-3">
                           <div class="full counter_section margin_bottom_30">
                              <div class="couter_icon">
                                 <div> 
                                    <i class="fa fa-clock-o blue1_color"></i>
                                 </div>
                              </div>
                              <div class="counter_no">
                                 <div>
                                    
                                    <p class="head_couter"><a href="view_lab.php">Lab Time</a></p>
                                 </div>
                              </div>
                           </div>
                        </div>
                        
                        <div class="col-md-6 col-lg-3">
                           <div class="full counter_section margin_bottom_30">
                              <div class="couter_icon">
                                 <div> 
                                    <i class="fa fa-comments-o red_color"></i>
                                 </div>
                              </div>
                              <div class="counter_no">
                                 <div>
                                    <p class="head_couter"><a href="view_test.php">Test</a></p>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="row column1 social_media_section">
                        
                        
                     </div>
                     <!-- graph -->
                    
                     <!-- end graph -->
                     <div class="row column3">
                        <!-- testimonial -->
                        
                        <!-- end testimonial -->
                        <!-- progress bar -->
                        
                        <!-- end progress bar -->
                     </div>
                     <div class="row column4 graph">
                        <div class="col-md-6 margin_bottom_30">
                           <div class="dash_blog">
                              <div class="dash_blog_inner">
                                 <div class="dash_head">
                                    <h3><span><i class="fa fa-calendar"></i> Edit Staff Information</span><span class="plus_green_bt"><a href="#">+</a></span></h3>
                                 </div>
                                 <div class="list_cont">
                                    
                                 </div>
                                 <div class="task_list_main">
                                    <form name="form1" class="contact-form" method="post">
									
									<div class="row">
									<div class="col-md-1">
									</div>
									<div class="col-md-10">
							
												
												<!-- form-item -->
												<div class="form-item">
													<input class="form-control" type="text" name="name" placeholder="Name" value="<?php echo $row['name']; ?>"/>
												</div><!-- End / form-item -->
												
												<br>
												<!-- form-item -->
												<div class="form-item">
													<input class="form-control" type="text" name="uname" placeholder="Staff ID" value="<?php echo $row['uname']; ?>" />
												</div><!-- End / form-item -->
												<br>
												<div class="form-item">
													<input class="form-control" type="text" name="mobile" maxlength="10" placeholder="Mobile No." value="<?php echo $row['mobile']; ?>" />
												</div><!-- End / form-item -->
												<br>
												<div class="form-item">
													<input class="form-control" type="text" name="email" placeholder="E-mail" value="<?php echo $row['email']; ?>" />
												</div><!-- End / form-item -->
												<br>
												<div class="form-item">
													<select class="form-control" type="text" name="stype">
													<option value="">-Type-</option>
													<option value="lab" <?php if($row['stype']=="lab") echo "selected"; ?>>Lab IN-Charge</option>
													<option value="staff" <?php if($row['stype']=="staff") echo "selected"; ?>>Staff</option>
													</select>
												</div><!-- End / form-item --><br>
												
												<br>
												<button class="main_bt read_bt" type="submit" name="btn" onClick="return validate()">Update</button>
												</div>
												</div>
											</form>
											<form name="form2" class="contact-form" method="post" enctype="multipart/form-data">
									
												<div class="row">
												<div class="col-md-1">
												</div>
												<div class="col-md-10">
							
												
												
												<div class="form-item">
												<label>Photo</label>
												<input class="form-control" type="file" name="file" placeholder="Photo" required />
												</div>
												<br>
												<button class="main_bt read_bt" type="submit" name="btn2">Change Photo</button>
												</div>
												</div>
												</form>
                                 </div>
                                
                              </div>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="dash_blog">
                              <div class="dash_blog_inner">
                                 <div class="dash_head">
                                    <h3><span><i class="fa fa-comments-o"></i> Staff</span></h3>
                                 </div>
                                 <div class="list_cont">
                                    <p>Information</p>
                                 </div>
                                 <div class="msg_list_main">
                                    <ul class="msg_list">
									<form name="form2" class="contact-form" method="post">
					<div class="row">
							<div class="col-lg-1">
							</div>
							<div class="col-lg-3">
							
							<select class="form-control" name="stype2">
							<option value="">-Type-</option>
													<option value="lab" <?php if($stype2=="lab") echo "selected"; ?>>Lab IN-Charge</option>
													<option value="staff" <?php if($stype2=="staff") echo "selected"; ?>>Staff</option>
							</select>
							</div>
							

							<div class="col-lg-3">
							<button class="btn btn-primary btn-round mb-30" type="submit" name="btn2">Go</button>
							</div>
						</div>
							</form>
									<?php
									
								if($stype2!="")
								{
								$q=" where stype='$stype2'"; 
								}
								
									$q1=mysqli_query($connect,"select * from vir_staff $q");
									while($r1=mysqli_fetch_array($q1))
									{
									?>
                                       <li>
									   <?php
									   if($r1['photo']!="")
									   {
									   ?> <span><img src="photo/<?php echo $r1['photo']; ?>" class="img-responsive" alt="#" /></span><?php
									   }
									   else
									   {
									   ?>
                                          <span><img src="images/proimg.jpg" class="img-responsive" alt="#" /></span>
                                         <?php
										 }
										 ?>
										  <span>
                                          <span class="name_user"><?php echo $r1['name']." [".$r1['uname']."]"; ?></span>
										  <span class="msg_user"><i class="fa fa-phone"></i> : <?php echo $r1['mobile']; ?></span><br>
                                          <span class="msg_user"><i class="fa fa-envelope-o"></i> : <?php echo $r1['email']; ?></span>
										 
                                          <span class="time_ago">
										 
										  <a href="edit_staff.php?sid=<?php echo $r1['id']; ?>">Edit</a> / <a href="add_staff.php?act=del&did=<?php echo $r1['id']; ?>" onClick="return del()">Delete</a></span>
                                          </span>
                                       </li>
                                      <?php
									 } 
									
									  ?> 
                                    </ul>
                                 </div>
                                <!-- <div class="read_more">
                                    <div class="center"><a class="main_bt read_bt" href="#">Read More</a></div>
                                 </div>-->
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <!-- footer -->
                  <div class="container-fluid">
                     <div class="footer">
                        <p>Virtual Lab
                            <a href="https://themewagon.com/"></a>
                        </p>
                     </div>
                  </div>
               </div>
               <!-- end dashboard inner -->
            </div>
         </div>
      </div>
      <!-- jQuery -->
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <!-- wow animation -->
      <script src="js/animate.js"></script>
      <!-- select country -->
      <script src="js/bootstrap-select.js"></script>
      <!-- owl carousel -->
      <script src="js/owl.carousel.js"></script> 
      <!-- chart js -->
      <script src="js/Chart.min.js"></script>
      <script src="js/Chart.bundle.min.js"></script>
      <script src="js/utils.js"></script>
      <script src="js/analyser.js"></script>
      <!-- nice scrollbar -->
      <script src="js/perfect-scrollbar.min.js"></script>
      <script>
         var ps = new PerfectScrollbar('#sidebar');
      </script>
      <!-- custom js -->
      <script src="js/custom.js"></script>
      <script src="js/chart_custom_style1.js"></script>
   </body>
</html>