<html>
<head><title>PHP</title></head><body>
<h3>Factorial of Given Number</h3>
<form name="form1" method="post" action="">
  <input type="text" name="n">
  <input type="submit" name="btn" value="Submit">
</form>
<?php
$sum="";
$a=array();
if(isset($_POST['btn']))
{
$f=0;
$n=$_POST['n'];
	for($i=1;$i<=$n;$i++)
	{
	$f=$f+$i;
	}
	echo "Sum is ".$f;
$sum="Sum is ".$f;
}
$fp=fopen("test/107/result.txt","w");
fwrite($fp,$sum);
?></body></html>
