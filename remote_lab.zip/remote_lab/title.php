<?php
echo "Cloud based On The Go Lab for Student Virtual Laboratories System";
?>