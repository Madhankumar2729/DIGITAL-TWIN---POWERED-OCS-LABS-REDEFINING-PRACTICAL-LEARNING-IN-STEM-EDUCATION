<?php
session_start();
include("dbconnect.php");
extract($_REQUEST);
$msg="";
$uname=$_SESSION['uname'];
$rdate=date("d-m-Y");

$qry=mysqli_query($connect,"select * from vir_student where regno='$uname'");
$row=mysqli_fetch_array($qry);
$dept=$row['department'];


$qry2=mysqli_query($connect,"select * from vir_test where id=$tid");
$row2=mysqli_fetch_array($qry2);
$time_min=$row2['time_min'];
$num_ques=$row2['num_ques'];
$lang=$row2['language'];

$qry21=mysqli_query($connect,"select * from vir_result where tid=$tid && regno='$uname'");
$row21=mysqli_fetch_array($qry21);

	if($row21['time_sec']>3)
	{
mysqli_query($connect,"update vir_result set time_sec=time_sec-5 where tid=$tid && regno='$uname'");
	}
	else
	{
mysqli_query($connect,"update vir_result set test_st=1 where tid=$tid && regno='$uname'");	
	}
?>
  <script>
//Using setTimeout to execute a function after 5 seconds.
setTimeout(function () {
   //Redirect with JavaScript
   window.location.href= 'time_sec.php?tid=<?php echo $tid; ?>';
}, 5000);
</script>