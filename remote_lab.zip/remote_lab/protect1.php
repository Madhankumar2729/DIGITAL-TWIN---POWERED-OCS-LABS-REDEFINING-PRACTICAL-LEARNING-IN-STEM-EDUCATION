<?php
session_start();
if($_SESSION['adminname']=="")
{
header("location:login.php");
}
?>