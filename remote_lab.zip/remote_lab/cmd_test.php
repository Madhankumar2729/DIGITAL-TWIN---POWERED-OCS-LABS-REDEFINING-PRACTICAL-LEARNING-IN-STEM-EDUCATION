<?php
session_start();
include("dbconnect.php");
extract($_REQUEST);
$uname=$_SESSION['uname'];
$current="";
$answer="";

if(!empty($_POST))
{
	$current=$_POST['cppcode'];
	$file="helloc.c";
	file_put_contents($file, $current);
	
	putenv("PATH=C:\Program Files (x86)\Dev-Cpp\MinGW64\bin");
	
	



	shell_exec("g++ helloc.c -o helloc.exe");//compile
	
	
	$answer=shell_exec("helloc.exe");
	
	$runcmd = "./a.out > output.txt";
$process_stdin = popen($runcmd, 'w');
fwrite($process_stdin, "text to send to process");
pclose($process_stdin);

}
/////////////////
$fq=mysqli_query($connect,"select * from vir_test_attend where tid=$tid && qid=$qid && regno='$uname'");
	$fr=mysqli_fetch_array($fq);
	$fn2=$fr['filename'];
	if($fn2!="")
	{
		$ss=explode(".",$fn2);
		
		$cc="";
		if($fname=="")
		{
		$fname=$ss[0];
			$xn=file("test/$uname/$fn2");
			foreach($xn as $xnn)
			{
			$cc.=$xnn;
			}
			
			$cppcode=$cc;
		}
	}
//////////////////////////////////
$qs=mysqli_query($connect,"select * from vir_question where id=$qid");
$rs=mysqli_fetch_array($qs);
$min1=$rs['min_lines'];
$max1=$rs['max_lines'];
$key=$rs['keywords'];
$qfile="q".$qid.".txt";

$qs2=mysqli_query($connect,"select * from vir_test where id=$tid");
$rs2=mysqli_fetch_array($qs2);
$mark=$rs2['mark'];
$tot_mark=$mark*$rs2['num_ques'];
?>
<style>
.txtarea {
resize: none;
outline:none;
width:500px;
height:500px;
border: 3px solid #cccccc;
padding: 5px;
font-family:Arial, Helvetica, sans-serif;
background-position:bottom right;
background-repeat:no-repeat;
font-size:14px;
color:#000000;

}
</style>
<form method="post">
<table border="0">
<tr>
<td>
	<textarea name="cppcode" style="background:#FFFFFF;" placeholder="Enter C code" class="txtarea"><?php  echo $cppcode; ?></textarea>
	<br />
	<input type="text" name="fname" value="<?php echo $fname; ?>" required />.c
	<input type="submit" name="btn2" value="Save" />
	<?php
	if(isset($btn2))
	{
	
	$fn=$fname.".c";
	$fp=fopen("test/$uname/$fn","w");
	fwrite($fp,$cppcode);
	
		/////////////////////
		mysqli_query($connect,"update vir_test_attend set filename='$fn' where tid=$tid && qid=$qid && regno='$uname'");
		////////////////////
	echo "File Saved";
	}
	?>
	<br />
	<br />
	<input type="submit" value="Save and Run" name="btn" />
</td>
<td>
	<?php
	
	if(isset($btn))
	{
		if($fname=="")
		{
		$fname="sample";
		}
	$fn=$fname.".c";
	$fp=fopen("test/$uname/$fn","w");
	fwrite($fp,$cppcode);
	/////////////////////
		mysqli_query($connect,"update vir_test_attend set filename='$fn' where tid=$tid && qid=$qid && regno='$uname'");
		////////////////////
		mysqli_query($connect,"update vir_test_attend set filename='$fn' where tid=$tid && qid=$qid");
		////////////////////
		$fx=file("test/$uname/$fn");
		$x=0;
		$line=0;
		$v=explode(",",$key);
		$cnt=count($v);
		//echo $cnt;
		$ar=array();
		foreach($fx as $fxx)
		{
		
		$line++;
				foreach($v as $k)
				{
					if (strpos($fxx, $k) !== false) 
					{
					$ar[]=$k;
					
					//echo 'true';
					}
				}
		}
		$ar2=array_unique($ar);
		//print_r($ar2);
		$x=count($ar2);
		/////lines///////////////////////////////////
		$ln=0;
		if($min1<=$line && $max1>=$line)
		{
		$ln=1;
		
		}
		//////key/////////////////////////////////
		$kn=0;
		if($cnt==$x)
		{
		$kn=2;
		}
		//////result///////////////////////////////////
		$fn3="test/$uname/test.txt";
		$fp3=fopen($fn3,"w");
		fwrite($fp3,$answer);
		fclose($fp3);
		////////////////////
		$rn=0;
		$z=0;
		$fp4=file($fn3);
		$nf1=count($fp4);
		$resfile=file("upload/$qfile");
		$nf2= count($resfile);
		if($nf1==$nf2)
		{
			for($y=0;$y<count($nf2);$y++)
			{
				if($resfile[$y]==$fp4[$y])
				{
				$z++;
				}	
			}
		}
		else
		{
		$rn=0;
		}
		
		if($z==$nf2)
		{
		$rn=2;
		}
		
		//$value=$ln+$kn+$rn;
		//echo $value;
		
		$m1=$mark/5;
		$val1=$m1*$ln;
		$val2=$m1*$kn;
		$val3=$m1*$rn;
		echo "$val1+$val2+$val3;";
		$value=$val1+$val2+$val3;
		echo "m=".$value;
		
		mysqli_query($connect,"update vir_test_attend set tot_mark=$mark,test_mark=$value where tid=$tid && qid=$qid && regno='$uname'");
		$tmark=0;
		$qt=mysqli_query($connect,"select * from vir_test_attend where tid=$tid && regno='$uname'");
		while($rt=mysqli_fetch_array($qt))
		{
		$tmark+=$rt['test_mark'];
		}
		
		$per=($tmark/$tot_mark)*100;
		mysqli_query($connect,"update vir_result set tot_mark=$tot_mark,test_mark=$tmark,percent=$per where tid=$tid && regno='$uname'");
		
		
	?>
	<textarea name="ccode2" style="background:#99CCFF" placeholder="See Result" class="txtarea"><?php  echo $answer; ?></textarea>
<?php
	}
	?>
</td>
</tr>
</table>
</form>
