<?php
include("protect.php");
include("dbconnect.php");
extract($_REQUEST);
$msg="";
$uname=$_SESSION['uname'];
$rdate=date("d-m-Y");


?>
<html>
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Virtual Lab</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- site icon -->
      <link rel="icon" href="images/fevicon.png" type="image/png" />
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css" />
      <!-- site css -->
      <link rel="stylesheet" href="style.css" />
      <!-- responsive css -->
      <link rel="stylesheet" href="css/responsive.css" />
      <!-- color css -->
      <link rel="stylesheet" href="css/colors.css" />
      <!-- select bootstrap -->
      <link rel="stylesheet" href="css/bootstrap-select.css" />
      <!-- scrollbar css -->
      <link rel="stylesheet" href="css/perfect-scrollbar.css" />
      <!-- custom css -->
      <link rel="stylesheet" href="css/custom.css" />
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->

   </head>
   <body class="dashboard dashboard_1">
      <div class="full_container">
         <div class="inner_container">
            <!-- Sidebar  -->
            <nav id="sidebar">
               <div class="sidebar_blog_1">
                  <div class="sidebar-header">
                     <div class="logo_section">
                        <a href=""></a>
                     </div>
                  </div>
				  <?php
				 $qry=mysqli_query($connect,"select * from vir_student where regno='$uname'");
$row=mysqli_fetch_array($qry);
$dept=$row['department'];


$qry2=mysqli_query($connect,"select * from vir_test where id=$tid");
$row2=mysqli_fetch_array($qry2);
$time_min=$row2['time_min'];
$num_ques=$row2['num_ques'];
$lang=$row2['language'];
$dept=$row2['dept'];

$q2=mysqli_query($connect,"select * from vir_result where tid=$tid && regno='$uname'");
$n2=mysqli_num_rows($q2);

$q22=mysqli_query($connect,"select * from vir_test_attend where tid=$tid && regno='$uname'");
$n22=mysqli_num_rows($q22);

if($n2==0 && $n22==0)
{

$mq=mysqli_query($connect,"select max(id) from vir_result");
$mr=mysqli_fetch_array($mq);
$id=$mr['max(id)']+1;
mysqli_query($connect,"insert into vir_result(id,regno,dept,language,tid,rdate) values($id,'$uname','$dept','$lang',$tid,'$rdate')");

	$q3=mysqli_query($connect,"select * from vir_question where language='$lang' order by rand() limit 0,$num_ques");
	while($r3=mysqli_fetch_array($q3))
	{
	$mq2=mysqli_query($connect,"select max(id) from vir_test_attend");
	$mr2=mysqli_fetch_array($mq2);
	$id2=$mr2['max(id)']+1;
	$qid=$r3['id'];
	mysqli_query($connect,"insert into vir_test_attend(id,regno,language,tid,qid) values($id2,'$uname','$lang','$tid','$qid')");
	}
	
}
/////////////////////////////////////////
if(is_dir("test/$uname")==false)
			{
			mkdir("test/$uname");
			}
////////////////////////////////

$q21=mysqli_query($connect,"select * from vir_result where tid=$tid && regno='$uname'");
$r21=mysqli_fetch_array($q21);
if($r21['test_st']==0 && $r21['time_sec']<=0)
{
$sec=$time_min*60;
mysqli_query($connect,"update vir_result set time_sec=$sec where tid=$tid && regno='$uname'");
}
////


////////////////////////////////
$q22=mysqli_query($connect,"select * from vir_result where tid=$tid && regno='$uname'");
$r22=mysqli_fetch_array($q22);
	$ts=$r22['time_sec']/60;
	
	$ts1=ceil($ts);
	$ts2=$r22['time_sec']%60;
	
	$tmin=$ts1.":".$ts2;
	
				  ?>
                  <div class="sidebar_user_info">
                     <div class="icon_setting"></div>
                     <div class="user_profle_side">
                        <div class="user_img"><?php
									   if($row['photo']!="")
									   {
									   ?> <span><img src="photo/<?php echo $row['photo']; ?>" class="img-responsive" alt="#" /></span><?php
									   }
									   else
									   {
									   ?>
                                          <span><img src="images/proimg.jpg" class="img-responsive" alt="#" /></span>
                                         <?php
										 }
										 ?></div>
                        <div class="user_info">
                           <h6><?php echo $row['name']; ?> [<?php echo $row['regno']; ?>]</h6>
                           <p><span class="online_animation"></span> Online</p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="sidebar_blog_2">
                  <h4>General</h4>
                  <ul class="list-unstyled components">
				  	 <li><a href="stu_home.php"><i class="fa fa-dashboard yellow_color"></i> <span>Dashboard</span></a></li>
                     <!--<li class="active">
                        <a href="#dashboard" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-dashboard yellow_color"></i> <span>Dashboard</span></a>
                        <ul class="collapse list-unstyled" id="dashboard">
                           <li>
                              <a href="dashboard.html">> <span>Default Dashboard</span></a>                           </li>
                           <li>
                              <a href="dashboard_2.html">> <span>Dashboard style 2</span></a>                           </li>
                        </ul>
                     </li>-->
                     <li><a href="report.php"><i class="fa fa-table purple_color2"></i> <span>Report</span></a></li>
                     <li>
                        <a href="#element" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-diamond purple_color"></i> <span>Files</span></a>
                        <ul class="collapse list-unstyled" id="element">
						
						
						<iframe src="time_sec.php?tid=<?php echo $tid; ?>" frameborder="0" width="2" height="2"></iframe>
						
						
						<?php
								$fq=mysqli_query($connect,"select * from vir_test_attend where regno='$uname' && tid=$tid && language='$lang'");
								while($fr=mysqli_fetch_array($fq))
								{
									if($fr['filename']!="")
									{
								?>
								
								<li><a href="test.php?tid=<?php echo $tid; ?>&qid=<?php echo $fr['qid']; ?>">> <span><?php echo $fr['filename']; ?></span></a></li>
								
								<?php
									}
								}
									?>
                          
                        </ul>
                     </li>
					 <li><a href="logout.php"><i class="fa fa-briefcase blue1_color"></i> <span>Logout</span></a></li>
                     <!--<li><a href="tables.html"><i class="fa fa-table purple_color2"></i> <span>Tables</span></a></li>
                     <li>
                        <a href="#apps" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-object-group blue2_color"></i> <span>Apps</span></a>
                        <ul class="collapse list-unstyled" id="apps">
                           <li><a href="email.html">> <span>Email</span></a></li>
                           <li><a href="calendar.html">> <span>Calendar</span></a></li>
                           <li><a href="media_gallery.html">> <span>Media Gallery</span></a></li>
                        </ul>
                     </li>
                     <li><a href="price.html"><i class="fa fa-briefcase blue1_color"></i> <span>Pricing Tables</span></a></li>
                     <li>
                        <a href="contact.html">
                        <i class="fa fa-paper-plane red_color"></i> <span>Contact</span></a>
                     </li>
                     <li class="active">
                        <a href="#additional_page" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-clone yellow_color"></i> <span>Additional Pages</span></a>
                        <ul class="collapse list-unstyled" id="additional_page">
                           <li>
                              <a href="profile.html">> <span>Profile</span></a>
                           </li>
                           <li>
                              <a href="project.html">> <span>Projects</span></a>
                           </li>
                           <li>
                              <a href="login.html">> <span>Login</span></a>
                           </li>
                           <li>
                              <a href="404_error.html">> <span>404 Error</span></a>
                           </li>
                        </ul>
                     </li>
                     <li><a href="map.html"><i class="fa fa-map purple_color2"></i> <span>Map</span></a></li>
                     <li><a href="charts.html"><i class="fa fa-bar-chart-o green_color"></i> <span>Charts</span></a></li>
                     <li><a href="settings.html"><i class="fa fa-cog yellow_color"></i> <span>Settings</span></a></li>-->
                  </ul>
               </div>
            </nav>
            <!-- end sidebar -->
            <!-- right content -->
            <div id="content">
               <!-- topbar -->
               <div class="topbar">
                  <nav class="navbar navbar-expand-lg navbar-light">
                     <div class="full">
                        <button type="button" id="sidebarCollapse" class="sidebar_toggle"><i class="fa fa-bars"></i></button>
                        <div class="logo_section">
                           <a href=""><?php
									   if($row['photo']!="")
									   {
									   ?> <span><img src="photo/<?php echo $row['photo']; ?>" class="img-responsive" alt="#" /></span><?php
									   }
									   else
									   {
									   ?>
                                          <span><img src="images/proimg.jpg" class="img-responsive" alt="#" /></span>
                                         <?php
										 }
										 ?></a>
                        </div>
                        <div class="right_topbar">
                           <div class="icon_info">
                             
                              <ul class="user_profile_dd">
                                 <li>
                                    <a class="dropdown-toggle" data-toggle="dropdown"><?php
									   if($row['photo']!="")
									   {
									   ?> <span><img src="photo/<?php echo $row['photo']; ?>" class="img-responsive" alt="#" /></span><?php
									   }
									   else
									   {
									   ?>
                                          <span><img src="images/proimg.jpg" class="img-responsive" alt="#" /></span>
                                         <?php
										 }
										 ?><span class="name_user"><?php echo $row['name']; ?></span></a>
                                    <div class="dropdown-menu">
                                       
                                       <a class="dropdown-item" href="logout.php"><span>Log Out</span> <i class="fa fa-sign-out"></i></a>
                                    </div>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </nav>
               </div>
               <!-- end topbar -->
               <!-- dashboard inner -->
               <div class="midde_cont">
                  <div class="container-fluid">
                     <div class="row column_title">
                        <div class="col-md-12">
                           <div class="page_title">
                              <h2>Dashboard</h2>
                           </div>
                        </div>
                     </div>
                   
                    
                     <!-- graph -->
                     
                     <!-- end graph -->
                     <div class="row column3">
                        <!-- testimonial -->
                        
                        <!-- end testimonial -->
                        <!-- progress bar -->
                        
                        <!-- end progress bar -->
                     </div>
                     <div class="row column4 graph">
                        <div class="col-md-12 margin_bottom_30">
                           <div class="dash_blog">
                              <div class="dash_blog_inner">
                                 <div class="dash_head">
								 
								 <!-- Display the countdown timer in an element -->

								 
								 
                                    <h3><span><i class="fa fa-calendar"></i> <?php
									echo $lang;
									?>  Test </span><span class="plus_green_bt"><a href="#">+</a></span></h3>
                                 </div>
                                 <div class="list_cont">
								 
                                    <p>
									
									 <h4>Test closes in <span id="time"> 00:00</span> minutes!</h4>
									 <form name="ff" method="post">
									 
									 </form>
									 	<script>
  function startTimer(duration, display) {
    var timer = duration, minutes, seconds;
    setInterval(function () {
      minutes = parseInt(timer / 60, 10);
      seconds = parseInt(timer % 60, 10);

      minutes = minutes < 10 ? "0" + minutes : minutes;
      seconds = seconds < 10 ? "0" + seconds : seconds;

      display.textContent = minutes + ":" + seconds;

      if (--timer < 0) {
        timer = duration;
		window.location.href="stu_home.php";
      }
    }, 1000);
  }

  window.onload = function () {
    var fiveMinutes = 60 * <?php echo $ts; ?>,
    display = document.querySelector('#time');
    startTimer(fiveMinutes, display);
  };

</script>

									<?php //echo "Lab Time: ".$row2['from_hour'].":".$row2['from_min']." to ".$row2['to_hour'].":".$row2['to_min']; ?></p>
                                 </div>
                                 <div class="task_list_main">
                                    <ul class="task_list">
                                      <?php
									  //$d=150%60;
									  //echo $d;
									  
									  //////////////////
									  $q4=mysqli_query($connect,"select * from vir_test_attend where tid=$tid && regno='$uname'");
$n4=mysqli_num_rows($q4);
if($n4>0)
{
$i=0;
?>
<div class="full price_table padding_infor_info">
<div class="row"><?php
	while($r4=mysqli_fetch_array($q4))
	{
	$i++;
	$qid=$r4['qid'];
		$q5=mysqli_query($connect,"select * from vir_question where id=$qid");
		$r5=mysqli_fetch_array($q5);
		//echo $i.".".$r5['question']."<br><br>";
		?>
		
		<div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 profile_details margin_bottom_30">
                                       <div class="contact_blog">
                                          <h4 class="brief">Program <?php echo $i; ?>:</h4>
                                          <div class="contact_inner">
                                             <div class="left">
                                                <h3><?php echo $lang; ?></h3>
                                                <p><strong></strong><?php echo $r5['question']; ?></p>
                                                <!--<ul class="list-unstyled">
                                                   <li><i class="fa fa-envelope-o"></i> : test@gmail.com</li>
                                                   <li><i class="fa fa-phone"></i> : 987 654 3210</li>
                                                </ul>-->
                                             </div>
                                             <!--<div class="right">
                                                <div class="profile_contacts">
                                                   <img class="img-responsive" src="images/layout_img/msg2.png" alt="#" />
                                                </div>
                                             </div>-->
                                             <div class="bottom_list">
                                                <!--<div class="left_rating">
                                                   <p class="ratings">
                                                      <a href="#"><span class="fa fa-star"></span></a>
                                                      <a href="#"><span class="fa fa-star"></span></a>
                                                      <a href="#"><span class="fa fa-star"></span></a>
                                                      <a href="#"><span class="fa fa-star"></span></a>
                                                      <a href="#"><span class="fa fa-star-o"></span></a>
                                                   </p>
                                                </div>-->
                                                <div class="right_button">
                                                   <!--<button type="button" class="btn btn-success btn-xs"> <i class="fa fa-user">
                                                   </i> <i class="fa fa-comments-o"></i> 
                                                   </button>-->
                                                   <a href="test.php?tid=<?php echo $tid; ?>&qid=<?php echo $qid; ?>" class="btn btn-primary btn-xs">
                                                   <i class="fa fa-user"> </i> Write Code
                                                   </a>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
		<?php
	}
	?></div></div><?php
}
									  //////////////////
								
								?>
                                    </ul>
                                 </div>
                                <!-- <div class="read_more">
                                    <div class="center"><a class="main_bt read_bt" href="#">Read More</a></div>
                                 </div>-->
                              </div>
                           </div>
                        </div>
                        <!--<div class="col-md-6">
                           
                        </div>-->
                     </div>
                  </div>
                  <!-- footer -->
                  <div class="container-fluid">
                     <div class="footer">
                        <p>Virtual Lab
                         <a href="https://themewagon.com/"></a>
                        </p>
                     </div>
                  </div>
               </div>
               <!-- end dashboard inner -->
            </div>
         </div>
      </div>
      <!-- jQuery -->
	 

      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <!-- wow animation -->
      <script src="js/animate.js"></script>
      <!-- select country -->
      <script src="js/bootstrap-select.js"></script>
      <!-- owl carousel -->
      <script src="js/owl.carousel.js"></script> 
      <!-- chart js -->
      <!--<script src="js/Chart.min.js"></script>
      <script src="js/Chart.bundle.min.js"></script>
      <script src="js/utils.js"></script>
      <script src="js/analyser.js"></script>-->
      <!-- nice scrollbar -->
      <script src="js/perfect-scrollbar.min.js"></script>
      <script>
         var ps = new PerfectScrollbar('#sidebar');
      </script>
      <!-- custom js -->
      <script src="js/custom.js"></script>
      <script src="js/chart_custom_style1.js"></script>
   </body>
</html>