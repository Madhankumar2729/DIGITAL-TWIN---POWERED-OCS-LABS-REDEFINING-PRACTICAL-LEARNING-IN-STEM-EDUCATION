<?php
$connect=mysqli_connect("localhost","root","","otg_lab");

?>