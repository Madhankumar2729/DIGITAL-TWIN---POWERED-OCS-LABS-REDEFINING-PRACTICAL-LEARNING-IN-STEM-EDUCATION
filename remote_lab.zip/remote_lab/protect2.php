<?php
session_start();
if($_SESSION['staffname']=="")
{
header("location:login_staff.php");
}
?>