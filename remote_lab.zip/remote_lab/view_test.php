<?php
session_start();
include("dbconnect.php");
extract($_REQUEST);
$msg="";
if(isset($btn))
{
$rd=explode("-",$rdate);
$rdate1=$rd[2]."-".$rd[1]."-".$rd[0];

$mq=mysqli_query($connect,"select max(id) from vir_test");
$mr=mysqli_fetch_array($mq);
$id=$mr['max(id)']+1;

	$ins=mysqli_query($connect,"insert into vir_test(id,dept,language,time_min,num_ques,mark,rdate) values($id,'$dept','$language','$time_min','$num_ques','$mark','$rdate1')");
	if($ins)
	{
	?>
	<script language="javascript">
	alert("Test Added Sucessfully");
	window.location.href="view_test.php";
	</script>
	<?php
	}
	
}
///////////////////////////
if($act=="del")
{
mysqli_query($connect,"delete from vir_test where id=$did");
?>
<script language="javascript">
window.location.href="view_test.php";
</script>
<?php
}
?>
<html>
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Virtual Lab</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- site icon -->
      <link rel="icon" href="images/fevicon.png" type="image/png" />
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css" />
      <!-- site css -->
      <link rel="stylesheet" href="style.css" />
      <!-- responsive css -->
      <link rel="stylesheet" href="css/responsive.css" />
      <!-- color css -->
      <link rel="stylesheet" href="css/colors.css" />
      <!-- select bootstrap -->
      <link rel="stylesheet" href="css/bootstrap-select.css" />
      <!-- scrollbar css -->
      <link rel="stylesheet" href="css/perfect-scrollbar.css" />
      <!-- custom css -->
      <link rel="stylesheet" href="css/custom.css" />
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->
<script language="javascript">
function del()
{
	if(!confirm("Are you sure want to Delete?"))
	{
	return false;
	}
	return true;
}
function validate()
{
	if(isNaN(document.form1.time_min.value))
	{
	document.getElementById("x1").style.display="block";
	document.getElementById("x2").style.display="none";
	document.getElementById("x3").style.display="none";
	return false;
	}
	else if(isNaN(document.form1.num_ques.value))
	{
	document.getElementById("x1").style.display="none";
	document.getElementById("x2").style.display="block";
	document.getElementById("x3").style.display="none";
	return false;
	}
	else if(isNaN(document.form1.mark.value))
	{
	document.getElementById("x1").style.display="none";
	document.getElementById("x2").style.display="none";
	document.getElementById("x3").style.display="block";
	return false;
	}
	else
	{
	document.getElementById("x1").style.display="none";
	document.getElementById("x2").style.display="none";
	document.getElementById("x3").style.display="none";
	}
return true;
}
</script>
				
   </head>
   <body class="dashboard dashboard_1">
      <div class="full_container">
         <div class="inner_container">
            <!-- Sidebar  -->
            <nav id="sidebar">
               <div class="sidebar_blog_1">
                  <div class="sidebar-header">
                     <div class="logo_section">
                        <a href=""><img class="logo_icon img-responsive" src="images/logo/logo_icon.png" alt="#" /></a>
                     </div>
                  </div>
                  <div class="sidebar_user_info">
                     <div class="icon_setting"></div>
                     <div class="user_profle_side">
                        <div class="user_img"><img class="img-responsive" src="images/logo/logo_icon.png" alt="#" /></div>
                        <div class="user_info">
                           <h6>Admin</h6>
                           <p><span class="online_animation"></span> Online</p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="sidebar_blog_2">
                  <h4>General</h4>
                  <ul class="list-unstyled components">
				  	<li><a href="admin.php"><i class="fa fa-dashboard yellow_color"></i> <span>Dashboard</span></a></li>
                     <!--<li class="active">
                        <a href="#dashboard" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-dashboard yellow_color"></i> <span>Dashboard</span></a>
                        <ul class="collapse list-unstyled" id="dashboard">
                           <li>
                              <a href="dashboard.html">> <span>Default Dashboard</span></a>
                           </li>
                           <li>
                              <a href="dashboard_2.html">> <span>Dashboard style 2</span></a>
                           </li>
                        </ul>
                     </li>-->
                     <li><a href="view_lab.php"><i class="fa fa-clock-o orange_color"></i> <span>Lab Time</span></a></li>
					 <li><a href="view_program.php"><i class="fa fa-diamond purple_color"></i> <span>Programs</span></a></li>
                     <!--<li>
                        <a href="#element" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-diamond purple_color"></i> <span>Programs</span></a>
                        <ul class="collapse list-unstyled" id="element">
                           <li><a href="general_elements.html">> <span>General Elements</span></a></li>
                           <li><a href="media_gallery.html">> <span>Media Gallery</span></a></li>
                           <li><a href="icons.html">> <span>Icons</span></a></li>
                           <li><a href="invoice.html">> <span>Invoice</span></a></li>
                        </ul>
                     </li>-->
                     <li><a href="view_test.php"><i class="fa fa-table purple_color2"></i> <span>Test</span></a></li>
                     <li>
                        <!--<a href="#apps" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-object-group blue2_color"></i> <span>Apps</span></a>
                        <ul class="collapse list-unstyled" id="apps">
                           <li><a href="email.html">> <span>Email</span></a></li>
                           <li><a href="calendar.html">> <span>Calendar</span></a></li>
                           <li><a href="media_gallery.html">> <span>Media Gallery</span></a></li>
                        </ul>-->
                     </li>
                     <li><a href="logout.php"><i class="fa fa-briefcase blue1_color"></i> <span>Logout</span></a></li>
                     <!--<li>
                        <a href="contact.html">
                        <i class="fa fa-paper-plane red_color"></i> <span>Contact</span></a>
                     </li>-->
                     <!--<li class="active">
                        <a href="#additional_page" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-clone yellow_color"></i> <span>Additional Pages</span></a>
                        <ul class="collapse list-unstyled" id="additional_page">
                           <li>
                              <a href="profile.html">> <span>Profile</span></a>
                           </li>
                           <li>
                              <a href="project.html">> <span>Projects</span></a>
                           </li>
                           <li>
                              <a href="login.html">> <span>Login</span></a>
                           </li>
                           <li>
                              <a href="404_error.html">> <span>404 Error</span></a>
                           </li>
                        </ul>
                     </li>
                     <li><a href="map.html"><i class="fa fa-map purple_color2"></i> <span>Map</span></a></li>
                     <li><a href="charts.html"><i class="fa fa-bar-chart-o green_color"></i> <span>Charts</span></a></li>
                     <li><a href="settings.html"><i class="fa fa-cog yellow_color"></i> <span>Settings</span></a></li>-->
                  </ul>
               </div>
            </nav>
            <!-- end sidebar -->
            <!-- right content -->
            <div id="content">
               <!-- topbar -->
               <div class="topbar">
                  <nav class="navbar navbar-expand-lg navbar-light">
                     <div class="full">
                        <button type="button" id="sidebarCollapse" class="sidebar_toggle"><i class="fa fa-bars"></i></button>
                        <div class="logo_section">
                           <a href="index.html"><img class="img-responsive" src="images/logo/logo.png" alt="#" /></a>
                        </div>
                        <div class="right_topbar">
                           <div class="icon_info">
                              
                              <ul class="user_profile_dd">
                                 <li>
                                    <a class="dropdown-toggle" data-toggle="dropdown"><img class="img-responsive rounded-circle" src="images/logo/logo_icon.png" alt="#" /><span class="name_user">Admin</span></a>
                                    <div class="dropdown-menu">
                                       
                                       <a class="dropdown-item" href="logout.php"><span>Log Out</span> <i class="fa fa-sign-out"></i></a>
                                    </div>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </nav>
               </div>
               <!-- end topbar -->
               <!-- dashboard inner -->
               <div class="midde_cont">
                  <div class="container-fluid">
                     <div class="row column_title">
                        <div class="col-md-12">
                           <div class="page_title">
                              <h2>Test</h2>
                           </div>
                        </div>
                     </div>
                     <div class="row column1">
                        
                     </div>
                     <div class="row column1 social_media_section">
                        
                        
                     </div>
                     <!-- graph -->
                    
                     <!-- end graph -->
                     <div class="row column3">
                        <!-- testimonial -->
                        
                        <!-- end testimonial -->
                        <!-- progress bar -->
                        
                        <!-- end progress bar -->
                     </div>
                     <div class="row column4 graph">
                        <div class="col-md-6 margin_bottom_30">
                           <div class="dash_blog">
                              <div class="dash_blog_inner">
                                 <div class="dash_head">
                                    <h3><span><i class="fa fa-calendar"></i> Add Test</span><span class="plus_green_bt"><a href="#">+</a></span></h3>
                                 </div>
                                 <div class="list_cont">
                                    
                                 </div>
                                 <div class="task_list_main">
                                    <form name="form1" class="contact-form" method="post" enctype="multipart/form-data">
									
									<div class="row">
									<div class="col-md-1">
									</div>
									<div class="col-md-10">
							
												
												<!-- form-item -->
												<div class="form-item">
													<select class="form-control" name="dept" required>
													<option value="">-Department-</option>
													<?php
													$cq=mysqli_query($connect,"select * from vir_department");
													while($cr=mysqli_fetch_array($cq))
													{
													?>
													<option><?php echo $cr['department']; ?></option>
													<?php
													}
													?>
													</select>
												</div><!-- End / form-item -->
												<br>
												<div class="form-item">
													<select name="language" class="form-control" required>
													<option value="">-Language-</option>
													<option>C Program</option>
													<option>CPP</option>
													<option>Java</option>
													<option>PHP</option>
													</select>
												</div><!-- End / form-item -->
												<br>
												<!-- form-item -->
												<div class="form-item">
													<input class="form-control" type="date" name="rdate" required />
												</div><!-- End / form-item -->
												<br>
												<div class="form-item">
													<input class="form-control" type="text" name="time_min" onBlur="return validate()" maxlength="4" placeholder="Time - Minutes" required />
													<span id="x1" style="display:none; color:#FF0000">Incorrect Time!</span>
												</div><!-- End / form-item -->
												<br>
												<div class="form-item">
													<input class="form-control" type="text" name="num_ques" maxlength="3" placeholder="No. of Questions" required />
													<span id="x2" style="display:none; color:#FF0000">Not a Number!</span>
												</div><!-- End / form-item -->
												<br>
												<div class="form-item">
													<input class="form-control" type="text" name="mark" maxlength="3" placeholder="Mark for Each Question" required />
													<span id="x3" style="display:none; color:#FF0000">Incorrect Mark!</span>
												</div><!-- End / form-item -->
												<br>		
												
												<button class="main_bt read_bt" type="submit" name="btn" onClick="return validate()">Add</button>
												</div>
												</div>
											</form>
                                 </div>
                                
                              </div>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="dash_blog">
                              <div class="dash_blog_inner">
                                 <div class="dash_head">
                                    <h3><span><i class="fa fa-comments-o"></i> View Test</span></h3>
                                 </div>
                                 <div class="list_cont">
                                    <p>Information</p>
                                 </div>
                                 <div class="msg_list_main">
                                    <ul class="msg_list">
									
									<form name="form1" class="contact-form" method="post">
					<div class="row">
							<div class="col-lg-1">
							</div>
							<div class="col-lg-3">
							
							<select class="form-control" name="dept2">
							<?php
							$cq2=mysqli_query($connect,"select * from vir_department");
							while($cr2=mysqli_fetch_array($cq2))
							{
							?>
							<option <?php if($cr2['department']==$dept2) echo "selected"; ?>><?php echo $cr2['department']; ?></option>
							<?php
							}
							?>
							</select>
							</div>
							

							<div class="col-lg-3">
							
							<select class="form-control" name="language2">
							<option value="">-All-</option>
							<option <?php if($language2=="C Program") echo "selected"; ?>>C Program</option>
							<option <?php if($language2=="CPP") echo "selected"; ?>>CPP</option>
							<option <?php if($language2=="Java") echo "selected"; ?>>Java</option>
							<option <?php if($language2=="PHP") echo "selected"; ?>>PHP</option>
							</select>
							</div>
							<div class="col-lg-3">
							<button class="btn btn-primary btn-round mb-30" type="submit" name="btn2">Go</button>
							</div>
						</div>
							</form>
									<?php
							if(isset($btn2))
							{
								if($dept2!="")
								{
								$q=" where dept='$dept2'"; 
								}
								if($language2!="")
								{
									if($q=="")
									{
									$q=" where language='$language2'";
									}
									else
									{
									$q.=" && language='$language2'";
									} 
								}
							$qry=mysqli_query($connect,"select * from vir_test $q");
							$num=mysqli_num_rows($qry);
							if($num>0)
							{
							while($row=mysqli_fetch_array($qry))
							{
							?>	
                                       <li>
									  
										  <span>
                                          <span class="name_user"><?php echo $row['language']." [".$row['dept']."]"; ?></span>
                                          <span class="msg_user"><?php echo "Time Duration: ".$row['time_min']." minutes"; 
							echo "<br>No. of Questions: ".$row['num_ques'];
							echo "<br>Each Question Mark: ".$row['mark']; 
							
							?></span>
										  <span class="msg_user"><?php echo $row['rdate']; ?></span>
                                          <span class="time_ago"><?php echo '<a href="view_test.php?act=del&did='.$row['id'].'" onclick="return del()">Delete</a>'; ?></span>
                                          </span>
                                       </li>
                                    <?php
									}
								}
								else
								{
								echo "Empty Result!!";
								}
							}
							?>
                                    </ul>
                                 </div>
                                 <!--<div class="read_more">
                                    <div class="center"><a class="main_bt read_bt" href="#">Read More</a></div>
                                 </div>-->
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <!-- footer -->
                  <div class="container-fluid">
                     <div class="footer">
                        <p>Virtual Lab
                            <a href="https://themewagon.com/"></a>
                        </p>
                     </div>
                  </div>
               </div>
               <!-- end dashboard inner -->
            </div>
         </div>
      </div>
      <!-- jQuery -->
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <!-- wow animation -->
      <script src="js/animate.js"></script>
      <!-- select country -->
      <script src="js/bootstrap-select.js"></script>
      <!-- owl carousel -->
      <script src="js/owl.carousel.js"></script> 
      <!-- chart js -->
      <script src="js/Chart.min.js"></script>
      <script src="js/Chart.bundle.min.js"></script>
      <script src="js/utils.js"></script>
      <script src="js/analyser.js"></script>
      <!-- nice scrollbar -->
      <script src="js/perfect-scrollbar.min.js"></script>
      <script>
         var ps = new PerfectScrollbar('#sidebar');
      </script>
      <!-- custom js -->
      <script src="js/custom.js"></script>
      <script src="js/chart_custom_style1.js"></script>
   </body>
</html>