-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 23, 2024 at 04:52 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `otg_lab`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `vir_assign`
--

CREATE TABLE `vir_assign` (
  `id` int(11) NOT NULL,
  `qid` int(11) NOT NULL,
  `language` varchar(20) NOT NULL,
  `dept` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vir_assign`
--

INSERT INTO `vir_assign` (`id`, `qid`, `language`, `dept`) VALUES
(1, 31, 'PHP', 'CSE'),
(2, 32, 'PHP', 'CSE'),
(4, 21, 'Java', 'CSE'),
(5, 22, 'Java', 'CSE'),
(6, 23, 'Java', 'CSE'),
(7, 24, 'Java', 'CSE'),
(8, 25, 'Java', 'CSE'),
(9, 34, 'PHP', 'CSE'),
(10, 1, 'C Program', 'CSE'),
(11, 3, 'C Program', 'CSE'),
(12, 4, 'C Program', 'CSE'),
(13, 5, 'C Program', 'CSE'),
(14, 2, 'CPP', 'CSE'),
(15, 7, 'CPP', 'CSE'),
(16, 8, 'CPP', 'CSE');

-- --------------------------------------------------------

--
-- Table structure for table `vir_attendance`
--

CREATE TABLE `vir_attendance` (
  `id` int(11) NOT NULL,
  `dept` varchar(20) NOT NULL,
  `regno` varchar(20) NOT NULL,
  `time_id` int(11) NOT NULL,
  `rdate` varchar(20) NOT NULL,
  `rtime` varchar(20) NOT NULL,
  `rtime2` varchar(20) NOT NULL,
  `seconds` double NOT NULL,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vir_attendance`
--

INSERT INTO `vir_attendance` (`id`, `dept`, `regno`, `time_id`, `rdate`, `rtime`, `rtime2`, `seconds`, `month`, `year`) VALUES
(1, 'CSE', '1101', 11, '20-04-2023', '09:15', '09:24', 100, 10, 2022),
(2, 'CSE', '1101', 2, '17-11-2022', '10:39', '10:41', 110, 11, 2022),
(3, 'CSE', '1101', 3, '17-11-2022', '12:58', '13:05', 350, 11, 2022),
(4, 'CSE', '1101', 3, '18-11-2022', '18:33', '18:33', 5, 11, 2022),
(5, 'CSE', '1101', 13, '26-03-2023', '13:36', '17:08', 435, 3, 2023),
(6, 'CSE', '1101', 1, '26-03-2023', '17:01', '', 0, 3, 2023),
(7, 'CSE', '1101', 13, '23-04-2023', '07:09', '08:16', 3540, 4, 2023),
(8, 'CSE', '1101', 0, '23-04-2023', '08:06', '', 0, 4, 2023);

-- --------------------------------------------------------

--
-- Table structure for table `vir_department`
--

CREATE TABLE `vir_department` (
  `id` int(11) NOT NULL,
  `department` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vir_department`
--

INSERT INTO `vir_department` (`id`, `department`) VALUES
(1, 'CSE'),
(2, 'IT');

-- --------------------------------------------------------

--
-- Table structure for table `vir_program`
--

CREATE TABLE `vir_program` (
  `id` int(11) NOT NULL,
  `regno` varchar(20) NOT NULL,
  `language` varchar(20) NOT NULL,
  `filename` varchar(50) NOT NULL,
  `lab_id` int(11) NOT NULL,
  `verify_st` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vir_program`
--

INSERT INTO `vir_program` (`id`, `regno`, `language`, `filename`, `lab_id`, `verify_st`) VALUES
(1, '1102', 'PHP', 'abc.php', 0, 0),
(2, '1102', 'PHP', 'new.php', 0, 0),
(3, '1102', 'C Program', 'rem.c', 0, 0),
(4, '1102', 'CPP', 'large.cpp', 0, 0),
(5, '1102', 'Java', 'palin.java', 0, 0),
(6, '1101', 'Java', 'fibo.java', 0, 0),
(7, '1101', 'C Program', 'mul.c', 0, 0),
(8, '1101', 'C Program', 'quo.c', 0, 0),
(9, '1101', 'Java', 'pali.java', 0, 0),
(10, '1101', 'Java', 'PalindromeExample.java', 0, 0),
(11, '1101', 'Java', 'FibonacciExample1.java', 0, 0),
(12, '1101', 'Java', 'PrimeExample.java', 0, 0),
(13, '1101', 'Java', 'FactorialExample.java', 0, 0),
(14, '1101', 'Java', 'RightTrianglePattern.java', 0, 0),
(15, '1101', 'Java', 'PrintAsciiValueExample1.java', 0, 0),
(16, '1101', 'Java', 'MulJava.java', 0, 0),
(17, '1101', 'Java', 'LeapDemo.java', 0, 0),
(18, '1101', 'Java', 'Vowel.java', 0, 0),
(19, '1101', 'Java', 'CheckArraysEqual.java', 0, 0),
(20, '1101', 'PHP', 'fact.php', 1, 1),
(21, '1101', 'PHP', 'calc.php', 2, 1),
(22, '1101', 'CPP', 'large.cpp', 0, 0),
(23, '1101', 'Java', 'triangle.java', 0, 0),
(24, '1101', 'C Program', 'even1.c', 0, 0),
(25, '1101', 'PHP', 'aa.php', 9, 1);

-- --------------------------------------------------------

--
-- Table structure for table `vir_question`
--

CREATE TABLE `vir_question` (
  `id` int(11) NOT NULL,
  `language` varchar(20) NOT NULL,
  `question` varchar(200) NOT NULL,
  `min_lines` int(11) NOT NULL,
  `max_lines` int(11) NOT NULL,
  `keywords` varchar(100) NOT NULL,
  `result` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vir_question`
--

INSERT INTO `vir_question` (`id`, `language`, `question`, `min_lines`, `max_lines`, `keywords`, `result`) VALUES
(1, 'C Program', 'C Program to Multiply Two Numbers, I/P=50,2', 8, 15, 'stdio.h,main,printf,scanf', 'q1.txt'),
(2, 'CPP', 'Find Largest 3 Numbers Using if Statement, I/P=25,100,85', 14, 20, 'iostream,if,cout', 'q2.txt'),
(3, 'C Program', 'C Program to Compute Quotient and Remainder, I/P=100/5', 10, 15, 'stdio.h,main,printf', 'q3.txt'),
(4, 'C Program', 'Swap Numbers Using Temporary Variable, I/P=10,20', 10, 15, 'stdio.h,main,printf', 'q4.txt'),
(5, 'C Program', 'Program to Check Even or Odd, I/P=30', 10, 15, 'stdio.h,main,printf', 'q5.txt'),
(6, 'C Program', 'Sum of Natural Numbers Using for Loop, I/P=5', 10, 15, 'stdio.h,main,printf', 'q6.txt'),
(7, 'CPP', 'Check if a number is even or odd. I/P=29', 10, 15, 'iostream,if,cout', 'q7.txt'),
(8, 'CPP', 'Write a program to swap two numbers. I/P=50,80', 10, 15, 'iostream,main,cout', 'q8.txt'),
(9, 'CPP', 'C++ Program to Calculate Sum of Natural Numbers using for loop, I/P=6', 10, 15, 'iostream,main,cout,for', 'q9.txt'),
(10, 'CPP', 'C++ Program to Reverse an Integer using while loop, I/P=246', 12, 20, 'iostream,main,cout,while', 'q10.txt'),
(11, 'C Program', 'Multiplication Table Up to 10 using for loop, I/P=8', 10, 15, 'stdio.h,main,printf,for', 'q11.txt'),
(12, 'C Program', 'Store Numbers and Calculate Average Using Arrays,I/P: n=3, 12,50,34', 15, 25, 'stdio.h,main,printf', 'q12.txt'),
(13, 'C Program', 'Store n no. for student Information in Structure and Display it, I/P: n=2, Raj,2231,94, Vijay,2232,86', 20, 30, 'stdio.h,main,printf,struct', 'q13.txt'),
(14, 'C Program', 'C Program to find largest element of an Array, I/P: n=4 # 45,87,93,31', 15, 25, 'stdio.h,main,printf', 'q14.txt'),
(15, 'C Program', 'Let see the c program to print half triangle by numbers 1 to 5 using for loop', 15, 25, 'stdio.h,main,printf,for', 'q15.txt'),
(16, 'CPP', 'C++ Program to Make a Simple Calculator to Add, Subtract, Multiply or Divide Using switch...case, I/P: * , 100,5', 20, 30, 'iostream,main,cout,swith,case,break', 'q16.txt'),
(17, 'CPP', 'C++ Program to Calculate Sum and Average of Numbers Using Arrays, I/P: n=3 # 20,45,25', 20, 30, 'iostream,main,cout', 'q17.txt'),
(18, 'CPP', 'Store n no. for Employee Information in Structure and Display it, I/P: n=2 # Nirmal,EM2201,15000, Vani,EM2202,18000', 20, 35, 'iostream,main,cout,struct', 'q18.txt'),
(19, 'CPP', 'program to add two numbers using a function, I/P: 48, 32', 10, 15, 'iostream,main,cout', 'q19.txt'),
(20, 'CPP', 'CPP Program to calculate Area, Volume using Objects-and-class, I/O: Length=15, Breadth=10, Height=12', 15, 30, 'iostream,main,cout,class,public', 'q20.txt'),
(21, 'Java', 'Palindrome program in java. In this java program, we will get a number variable and check whether number is palindrome or not. I/P: 454', 15, 20, 'class,main,int,System', 'q21.txt'),
(22, 'Java', 'fibonacci series program in java without using recursion. I/P: 10', 12, 20, 'class,main,int,System', 'q22.txt'),
(23, 'Java', 'Prime number program in java. In this java program, we will take a number variable and check whether the number is prime or not. I/P:3', 15, 20, 'class,main,int,System', 'q23.txt'),
(24, 'Java', 'factorial Program using for loop in java. I/P: 5', 8, 15, 'class,main,int,System', 'q24.txt'),
(25, 'Java', 'create the logic for the RightTrianglePattern *', 10, 20, 'class,main,int,System', 'q25.txt'),
(26, 'Java', 'Find the ASCII value of a character through a Java program. I/P: a,g', 10, 15, 'class,main,int,System', 'q26.txt'),
(27, 'Java', 'Program to read two integer and print product of them, I/P: 15,10', 5, 15, 'class,main,int,System', 'q27.txt'),
(28, 'Java', 'Program to check whether the input year is leap or not, I/P: 2022', 15, 25, 'class,main,int,System', 'q28.txt'),
(29, 'Java', 'Program to check Vowel or Consonant using Switch Case, I/P: e', 20, 35, 'class,main,int,System', 'q29.txt'),
(30, 'Java', 'Java Program to Check if two Arrays are Equal or not, I/P: 30,25,40 # 30,25,40', 10, 20, 'class,main,int,System', 'q30.txt'),
(31, 'PHP', 'Factorial of given number, I/P: 5', 20, 35, '?php,form,POST,input', 'q31.txt'),
(32, 'PHP', 'Calculate Given 2 numbers by Selected Operator using switch case, I/P: - , 45,20', 20, 40, '?php,form,POST,input,switch,case', 'q32.txt'),
(33, 'PHP', 'Biggest of given 3 numbers using if condition, I/P: 58,148,137', 20, 40, '?php,form,POST,input,if', 'q33.txt'),
(34, 'PHP', 'Find given number is odd or even using function, I/P: 250', 25, 35, '?php,form,POST,input,function', 'q34.txt'),
(35, 'PHP', 'Sum of n Numbers using array, I/P: 150,80,30,40', 15, 25, '?php,array', 'q35.txt');

-- --------------------------------------------------------

--
-- Table structure for table `vir_result`
--

CREATE TABLE `vir_result` (
  `id` int(11) NOT NULL,
  `regno` varchar(20) NOT NULL,
  `dept` varchar(20) NOT NULL,
  `language` varchar(20) NOT NULL,
  `tid` int(11) NOT NULL,
  `rdate` varchar(15) NOT NULL,
  `time_sec` double NOT NULL,
  `test_st` int(11) NOT NULL,
  `tot_mark` double NOT NULL,
  `test_mark` double NOT NULL,
  `percent` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vir_result`
--

INSERT INTO `vir_result` (`id`, `regno`, `dept`, `language`, `tid`, `rdate`, `time_sec`, `test_st`, `tot_mark`, `test_mark`, `percent`) VALUES
(1, '1101', 'CSE', 'CPP', 4, '30-09-2022', 90, 0, 20, 0, 0),
(3, '1101', 'CSE', 'C Program', 2, '28-09-2022', 0, 0, 20, 10, 50),
(4, '1101', 'CSE', 'Java', 5, '30-09-2022', 0, 1, 0, 0, 0),
(5, '1101', 'CSE', 'PHP', 3, '06-10-2022', 0, 0, 0, 0, 0),
(6, '1101', 'CSE', 'PHP', 6, '06-10-2022', 5, 1, 0, 0, 0),
(7, '1102', 'CSE', 'PHP', 6, '06-10-2022', 550, 0, 20, 18, 90),
(8, '1101', 'CSE', 'PHP', 7, '20-04-2023', 960, 0, 20, 8, 40);

-- --------------------------------------------------------

--
-- Table structure for table `vir_staff`
--

CREATE TABLE `vir_staff` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `stype` varchar(20) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `department` varchar(30) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `photo` varchar(30) NOT NULL,
  PRIMARY KEY  (`uname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vir_staff`
--

INSERT INTO `vir_staff` (`id`, `name`, `stype`, `uname`, `mobile`, `email`, `department`, `pass`, `photo`) VALUES
(1, 'Ramesh', 'lab', 'SS1', 9638512455, 'ramesh@gmail.com', '', '12345', 'S1face16.jpg'),
(2, 'Kumar', 'staff', 'SS2', 8956452235, 'kumar@gmail.com', '', '12345', '');

-- --------------------------------------------------------

--
-- Table structure for table `vir_student`
--

CREATE TABLE `vir_student` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `regno` varchar(20) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `department` varchar(30) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `photo` varchar(30) NOT NULL,
  PRIMARY KEY  (`regno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vir_student`
--

INSERT INTO `vir_student` (`id`, `name`, `regno`, `mobile`, `email`, `department`, `pass`, `photo`) VALUES
(1, 'Vignesh', '1101', 9048261035, 'vignesh@gmail.com', 'CSE', '12345', ''),
(2, 'Surya', '1102', 9685741594, 'surya@gmail.com', 'CSE', '32285', 'P2msg4.png'),
(3, 'Saran', '1121', 9845446452, 'saran@gmail.com', 'CSE', '88568', 'P3face11.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `vir_test`
--

CREATE TABLE `vir_test` (
  `id` int(11) NOT NULL,
  `dept` varchar(30) NOT NULL,
  `language` varchar(20) NOT NULL,
  `time_min` int(11) NOT NULL,
  `num_ques` int(11) NOT NULL,
  `mark` double NOT NULL,
  `rdate` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vir_test`
--

INSERT INTO `vir_test` (`id`, `dept`, `language`, `time_min`, `num_ques`, `mark`, `rdate`) VALUES
(2, 'CSE', 'C Program', 3, 2, 10, '15-09-2022'),
(4, 'CSE', 'CPP', 2, 2, 10, '30-09-2022'),
(5, 'CSE', 'Java', 10, 2, 10, '18-11-2022'),
(7, 'CSE', 'PHP', 20, 2, 10, '23-04-2023');

-- --------------------------------------------------------

--
-- Table structure for table `vir_test_attend`
--

CREATE TABLE `vir_test_attend` (
  `id` int(11) NOT NULL,
  `regno` varchar(20) NOT NULL,
  `language` varchar(20) NOT NULL,
  `tid` int(11) NOT NULL,
  `qid` int(11) NOT NULL,
  `filename` varchar(100) NOT NULL,
  `tot_mark` double NOT NULL,
  `test_mark` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vir_test_attend`
--

INSERT INTO `vir_test_attend` (`id`, `regno`, `language`, `tid`, `qid`, `filename`, `tot_mark`, `test_mark`) VALUES
(1, '1101', 'CPP', 4, 20, '', 0, 0),
(2, '1101', 'CPP', 4, 18, 'f1.cpp', 10, 0),
(5, '1101', 'C Program', 2, 5, 'odd.c', 10, 10),
(6, '1101', 'C Program', 2, 4, '', 0, 0),
(7, '1101', 'Java', 5, 25, '', 0, 0),
(8, '1101', 'Java', 5, 21, '', 0, 0),
(11, '1102', 'PHP', 6, 35, 'sum.php', 10, 8),
(12, '1102', 'PHP', 6, 31, 'fact.php', 10, 10),
(13, '1101', 'PHP', 7, 34, 'even.php', 10, 8),
(14, '1101', 'PHP', 7, 32, '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `vir_time`
--

CREATE TABLE `vir_time` (
  `id` int(11) NOT NULL,
  `dept` varchar(20) NOT NULL,
  `language` varchar(20) NOT NULL,
  `day1` varchar(20) NOT NULL,
  `from_hour` int(11) NOT NULL,
  `from_min` int(11) NOT NULL,
  `to_hour` int(11) NOT NULL,
  `to_min` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vir_time`
--

INSERT INTO `vir_time` (`id`, `dept`, `language`, `day1`, `from_hour`, `from_min`, `to_hour`, `to_min`) VALUES
(1, 'CSE', 'C Program', 'Saturday', 14, 15, 16, 15),
(2, 'CSE', 'CPP', 'Thursday', 10, 25, 11, 30),
(3, 'CSE', 'Java', 'Friday', 18, 30, 20, 30),
(4, 'CSE', 'PHP', 'Saturday', 17, 0, 19, 55),
(5, 'CSE', 'CPP', 'Saturday', 14, 0, 16, 30),
(6, 'CSE', 'Java', 'Thursday', 18, 0, 20, 30),
(7, 'CSE', 'PHP', 'Thursday', 14, 0, 16, 0),
(8, 'CSE', 'C Program', 'Tuesday', 11, 30, 13, 0),
(9, 'CSE', 'CPP', 'Tuesday', 11, 45, 12, 45),
(10, 'CSE', 'Java', 'Monday', 11, 30, 13, 30),
(11, 'CSE', 'PHP', 'Tuesday', 18, 45, 20, 45),
(12, 'CSE', 'Java', 'Tuesday', 11, 45, 12, 45),
(13, 'CSE', 'PHP', 'Sunday', 7, 0, 9, 30);
