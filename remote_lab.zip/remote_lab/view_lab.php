<?php
session_start();
include("dbconnect.php");
extract($_REQUEST);
$msg="";
if(isset($btn))
{
	
$mq=mysqli_query($connect,"select max(id) from vir_time");
$mr=mysqli_fetch_array($mq);
$id=$mr['max(id)']+1;

	
	$q1=mysqli_query($connect,"select * from vir_time where day1='$day'");
	$n1=mysqli_num_rows($q1);
	if($n1==0)
	{
	
	}
	

	$ins=mysqli_query($connect,"insert into vir_time(id,dept,language,day1,from_hour,from_min,to_hour,to_min) values($id,'$dept','$language','$day1','$from_hour','$from_min','$to_hour','$to_min')");
	if($ins)
	{
	?>
	<script language="javascript">
	alert("Lab Time Added Sucessfully");
	window.location.href="view_lab.php";
	</script>
	<?php
	}
	
}
///////////////////////////
if($act=="del")
{
mysqli_query($connect,"delete from vir_time where id=$did");
?>
<script language="javascript">
window.location.href="view_lab.php";
</script>
<?php
}
?>
<html>
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Virtual Lab</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- site icon -->
      <link rel="icon" href="images/fevicon.png" type="image/png" />
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css" />
      <!-- site css -->
      <link rel="stylesheet" href="style.css" />
      <!-- responsive css -->
      <link rel="stylesheet" href="css/responsive.css" />
      <!-- color css -->
      <link rel="stylesheet" href="css/colors.css" />
      <!-- select bootstrap -->
      <link rel="stylesheet" href="css/bootstrap-select.css" />
      <!-- scrollbar css -->
      <link rel="stylesheet" href="css/perfect-scrollbar.css" />
      <!-- custom css -->
      <link rel="stylesheet" href="css/custom.css" />
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->
<script language="javascript">
function del()
{
	if(!confirm("Are you sure want to Delete?"))
	{
	return false;
	}
	return true;
}

            function validate()
            {
			  
                if (document.form1.name.value == "")
                {
                    alert("Enter the Name");
                    document.form1.name.focus();
                    return false;
                }
				var name=document.form1.name;
			    var letters = /^[A-Za-z. ]+$/;  
				if(name.value.match(letters))  
				{  
				//return true;  
				}  
				else  
				{  
				alert('Username must have alphabet characters only');  
				document.form1.name.select();  
				return false;  
				}
				if (document.form1.regno.value == "")
                {
                    alert("Enter the Register No.");
                    document.form1.regno.focus();
                    return false;
                }
				if (document.form1.mobile.value == "")
                {
                    alert("Enter the Mobile No.");
                    document.form1.mobile.focus();
                    return false;
                }
				if (isNaN(document.form1.mobile.value))
                {
                    alert("Invalid Mobile No.");
                    document.form1.mobile.select();
                    return false;
                }
				if (document.form1.mobile.value.length != 10)
                {
                    alert("10 digists only allowed!!");
                    document.form1.mobile.select();
                    return false;
                }
                if (document.form1.email.value == "")
                {
                    alert("Enter the E-mail");
                    document.form1.email.focus();
                    return false;
                }
				if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(document.form1.email.value))  
				  {  
					//return (true)  
				  }  
				  else
				  {
					alert("You have entered an invalid email address!");
					document.form1.email.select();
					return false; 
				  }
               if (document.form1.dept.selectedIndex == 0)
                {
                    alert("Select the Department");
                    document.form1.dept.focus();
                    return false;
                }
				
				return true;
				}
				</script>
				
   </head>
   <body class="dashboard dashboard_1">
      <div class="full_container">
         <div class="inner_container">
            <!-- Sidebar  -->
            <nav id="sidebar">
               <div class="sidebar_blog_1">
                  <div class="sidebar-header">
                     <div class="logo_section">
                        <a href=""><img class="logo_icon img-responsive" src="images/logo/logo_icon.png" alt="#" /></a>
                     </div>
                  </div>
                  <div class="sidebar_user_info">
                     <div class="icon_setting"></div>
                     <div class="user_profle_side">
                        <div class="user_img"><img class="img-responsive" src="images/logo/logo_icon.png" alt="#" /></div>
                        <div class="user_info">
                           <h6>Admin</h6>
                           <p><span class="online_animation"></span> Online</p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="sidebar_blog_2">
                  <h4>General</h4>
                  <?php include("link_admin.php"); ?>
               </div>
            </nav>
            <!-- end sidebar -->
            <!-- right content -->
            <div id="content">
               <!-- topbar -->
               <div class="topbar">
                  <nav class="navbar navbar-expand-lg navbar-light">
                     <div class="full">
                        <button type="button" id="sidebarCollapse" class="sidebar_toggle"><i class="fa fa-bars"></i></button>
                        <div class="logo_section">
                           <a href="index.html"><img class="img-responsive" src="images/logo/logo.png" alt="#" /></a>
                        </div>
                        <div class="right_topbar">
                           <div class="icon_info">
                              
                              <ul class="user_profile_dd">
                                 <li>
                                    <a class="dropdown-toggle" data-toggle="dropdown"><img class="img-responsive rounded-circle" src="images/logo/logo_icon.png" alt="#" /><span class="name_user">Admin</span></a>
                                    <div class="dropdown-menu">
                                       
                                       <a class="dropdown-item" href="logout.php"><span>Log Out</span> <i class="fa fa-sign-out"></i></a>
                                    </div>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </nav>
               </div>
               <!-- end topbar -->
               <!-- dashboard inner -->
               <div class="midde_cont">
                  <div class="container-fluid">
                     <div class="row column_title">
                        <div class="col-md-12">
                           <div class="page_title">
                              <h2>Lab Time</h2>
                           </div>
                        </div>
                     </div>
                     <div class="row column1">
                        
                     </div>
                     <div class="row column1 social_media_section">
                        
                        
                     </div>
                     <!-- graph -->
                    
                     <!-- end graph -->
                     <div class="row column3">
                        <!-- testimonial -->
                        
                        <!-- end testimonial -->
                        <!-- progress bar -->
                        
                        <!-- end progress bar -->
                     </div>
                     <div class="row column4 graph">
                        <div class="col-md-6 margin_bottom_30">
                           <div class="dash_blog">
                              <div class="dash_blog_inner">
                                 <div class="dash_head">
                                    <h3><span><i class="fa fa-calendar"></i> Add Lab Time</span><span class="plus_green_bt"><a href="#">+</a></span></h3>
                                 </div>
                                 <div class="list_cont">
                                    
                                 </div>
                                 <div class="task_list_main">
                                    <form name="form1" class="contact-form" method="post" enctype="multipart/form-data">
									
									<div class="row">
									<div class="col-md-1">
									</div>
									<div class="col-md-10">
							
												
												<!-- form-item -->
												<div class="form-item">
													<select class="form-control" name="dept" required>
													<option value="">-Department-</option>
													<?php
													$cq=mysqli_query($connect,"select * from vir_department");
													while($cr=mysqli_fetch_array($cq))
													{
													?>
													<option><?php echo $cr['department']; ?></option>
													<?php
													}
													?>
													</select>
												</div><!-- End / form-item -->
												<br>
												<div class="form-item">
													<select name="language" class="form-control" required>
													<option value="">-Language-</option>
													<option>C Program</option>
													<option>CPP</option>
													<option>Java</option>
													<option>PHP</option>
													</select>
												</div><!-- End / form-item -->
												<br>
												<!-- form-item -->
												<div class="form-item">
													<select name="day1" class="form-control">
													<option>Monday</option>
													<option>Tuesday</option>
													<option>Wednesday</option>
													<option>Thursday</option>
													<option>Friday</option>
													<option>Saturday</option>
													</select>
												</div><!-- End / form-item -->
												<br>
												<div class="form-item">
													<label>Period From</label>
													<select name="from_hour" class="form-control">
													<option value="9">-Hour-</option>
													<option>9</option>
													<option>10</option>
													<option>11</option>
													<option>12</option>
													<option>13</option>
													<option>14</option>
													<option>15</option>
													<option>16</option>
													</select>
													
													<select name="from_min" class="form-control">
													<option value="0">-Min-</option>
													<option>0</option>
													<option>15</option>
													<option>30</option>
													<option>45</option>
													</select>
												</div><!-- End / form-item -->
												<br>
												<div class="form-item">
													<label>Period To</label>
													<select name="to_hour" class="form-control">
													<option value="10">-Hour-</option>
													<option>10</option>
													<option>11</option>
													<option>12</option>
													<option>13</option>
													<option>14</option>
													<option>15</option>
													<option>16</option>
													<option>17</option>
													</select>
													
													<select name="to_min" class="form-control">
													<option value="0">-Min-</option>
													<option>0</option>
													<option>15</option>
													<option>30</option>
													<option>45</option>
													</select>
												</div><!-- End / form-item -->
												<br>
																
												
												<button class="main_bt read_bt" type="submit" name="btn" onClick="return validate()">Add</button>
												</div>
												</div>
											</form>
                                 </div>
                                
                              </div>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="dash_blog">
                              <div class="dash_blog_inner">
                                 <div class="dash_head">
                                    <h3><span><i class="fa fa-comments-o"></i> Lab Time</span></h3>
                                 </div>
                                 <div class="list_cont">
                                    <p>Information</p>
                                 </div>
                                 <div class="msg_list_main">
                                    <ul class="msg_list">
									
									<form name="form1" class="contact-form" method="post">
					<div class="row">
							<div class="col-lg-1">
							</div>
							<div class="col-lg-3">
							
							<select class="form-control" name="dept2">
							<?php
							$cq2=mysqli_query($connect,"select * from vir_department");
							while($cr2=mysqli_fetch_array($cq2))
							{
							?>
							<option <?php if($cr2['department']==$dept2) echo "selected"; ?>><?php echo $cr2['department']; ?></option>
							<?php
							}
							?>
							</select>
							</div>
							

							<div class="col-lg-3">
							
							<select class="form-control" name="language2">
							<option value="">-All-</option>
							<option <?php if($language2=="C Program") echo "selected"; ?>>C Program</option>
							<option <?php if($language2=="CPP") echo "selected"; ?>>CPP</option>
							<option <?php if($language2=="Java") echo "selected"; ?>>Java</option>
							<option <?php if($language2=="PHP") echo "selected"; ?>>PHP</option>
							</select>
							</div>
							<div class="col-lg-3">
							<button class="btn btn-primary btn-round mb-30" type="submit" name="btn2">Go</button>
							</div>
						</div>
							</form>
									<?php
							if(isset($btn2))
							{
								if($dept2!="")
								{
								$q=" where dept='$dept2'"; 
								}
								if($language2!="")
								{
									if($q=="")
									{
									$q=" where language='$language2'";
									}
									else
									{
									$q.=" && language='$language2'";
									} 
								}
							$qry=mysqli_query($connect,"select * from vir_time $q");
							$num=mysqli_num_rows($qry);
							if($num>0)
							{
							while($row=mysqli_fetch_array($qry))
							{
							?>	
                                       <li>
									  
										  <span>
                                          <span class="name_user"><?php echo $row['language']." [".$row['dept']."]"; ?></span>
                                          <span class="msg_user"><?php echo $row['day1']; ?></span>
										  <span class="msg_user"><?php
							echo $row['from_hour'].":".$row['from_min']." to ".$row['to_hour'].":".$row['to_min'];
							
							?></span>
                                          <span class="time_ago"><?php echo '<a href="view_lab.php?act=del&did='.$row['id'].'" onclick="return del()">Delete</a>'; ?></span>
                                          </span>
                                       </li>
                                    <?php
									}
								}
								else
								{
								echo "Empty Result!!";
								}
							}
							?>
                                    </ul>
                                 </div>
                                 <!--<div class="read_more">
                                    <div class="center"><a class="main_bt read_bt" href="#">Read More</a></div>
                                 </div>-->
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <!-- footer -->
                  <div class="container-fluid">
                     <div class="footer">
                        <p><?php include("title1.php"); ?>
                            <a href="https://themewagon.com/"></a>
                        </p>
                     </div>
                  </div>
               </div>
               <!-- end dashboard inner -->
            </div>
         </div>
      </div>
      <!-- jQuery -->
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <!-- wow animation -->
      <script src="js/animate.js"></script>
      <!-- select country -->
      <script src="js/bootstrap-select.js"></script>
      <!-- owl carousel -->
      <script src="js/owl.carousel.js"></script> 
      <!-- chart js -->
      <script src="js/Chart.min.js"></script>
      <script src="js/Chart.bundle.min.js"></script>
      <script src="js/utils.js"></script>
      <script src="js/analyser.js"></script>
      <!-- nice scrollbar -->
      <script src="js/perfect-scrollbar.min.js"></script>
      <script>
         var ps = new PerfectScrollbar('#sidebar');
      </script>
      <!-- custom js -->
      <script src="js/custom.js"></script>
      <script src="js/chart_custom_style1.js"></script>
   </body>
</html>