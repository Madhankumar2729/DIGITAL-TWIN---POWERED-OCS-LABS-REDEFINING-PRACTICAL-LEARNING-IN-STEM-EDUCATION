<?php
session_start();
if($_SESSION['labname']=="")
{
header("location:login_lab.php");
}
?>