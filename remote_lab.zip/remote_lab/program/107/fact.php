<html>
<head>
<title>PHP</title>
</head>

<body>
<h3>Factorial of Given Number</h3>
<form name="form1" method="post" action="">
  <input type="text" name="n">
  <input type="submit" name="btn" value="Submit">
</form>
<?php
if(isset($_POST['btn']))
{
$f=1;
$n=$_POST['n'];
	for($i=1;$i<=$n;$i++)
	{
	$f=$f*$i;
	}
	echo "Factorial of $n is ".$f;
}
?>
</body>
</html>