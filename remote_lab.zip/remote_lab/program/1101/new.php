<html>
<head>
<title>web</title>
</head>
<body bgcolor="pink">
<?php
extract($_REQUEST);

?>
<form name="form1" method="post">
<h3>Multiplication</h3>
<input type="text" name="a"><br>
<input type="text" name="b"><br>
<input type="submit" name="btn" value="Multiply"><br> 
</form>
<?php
if(isset($btn))
{
$c=$a*$b;
echo "Multiply=".$c;
}
?>
</body>
</html>