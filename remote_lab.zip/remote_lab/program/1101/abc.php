<html>
<head>
<title>web</title>
</head>
<body bgcolor="yellow">
<?php
extract($_REQUEST);

?>
<form name="form1" method="post">
<input type="text" name="a"><br>
<input type="text" name="b"><br>
<input type="submit" name="btn" value="Add"><br> 
</form>
<?php
if(isset($btn))
{
$c=$a+$b;
echo "Sum=".$c;
}
?>
</body>
</html>