<html>
<head>
<title>PHP</title>
</head>

<body>
<h3>Calculate Given 2 numbers by Selected Operator using switch case</h3>
<form name="form1" method="post" action="">
 Operator<select name="op">
 <option value="">-Select-</option>
 <option value="1">+</option>
 <option value="2">-</option>
 <option value="3">*</option>
 <option value="4">/</option>
 </select><br>
  Value1 <input type="text" name="a"><br>
  Value2 <input type="text" name="b"><br>
  <input type="submit" name="btn" value="Submit">
</form>
<?php
if(isset($_POST['btn']))
{

$op=$_POST['op'];
$a=$_POST['a'];
$b=$_POST['b'];
	switch($op)
	{
		case '1': $c=$a+$b; echo "Addition of $a and $b is ".$c; break;
		case '2': $c=$a-$b; echo "Subtraction of $a and $b is ".$c; break;
		case '3': $c=$a*$b; echo "Multiplication of $a and $b is ".$c; break;
		case '4': $c=$a/$b; echo "Division of $a and $b is ".$c; break;
		default: echo "Select any option";
	}	
	
}
?>
</body>
</html>
