#include <stdio.h>
int main() {
    int dividend=100, divisor=21, quotient, remainder;
    printf("Enter dividend: ");
    //scanf("%d", ÷nd);
  
    printf("Enter divisor: ");
   // scanf("%d", &divisor);

    // Computes quotient
    quotient = dividend / divisor;

    // Computes remainder
    remainder = dividend % divisor;

    printf("Quotient = %d\n", quotient);
    printf("Remainder = %d", remainder);
    return 0;
}