<?php
session_start();
include("dbconnect.php");
extract($_REQUEST);
$msg="";
if(isset($btn))
{
	
$mq=mysqli_query($connect,"select max(id) from vir_student");
$mr=mysqli_fetch_array($mq);
$id=$mr['max(id)']+1;
$pass=rand(10000,99999);

$fn="";
if($_FILES['file']['name']!="")
{
$fn="P".$id.$_FILES['file']['name'];
move_uploaded_file($_FILES['file']['tmp_name'],"photo/".$fn);
}

	$ins=mysqli_query($connect,"insert into vir_student(id,name,regno,mobile,email,department,pass,photo) values($id,'$name','$regno','$mobile','$email','$dept','$pass','$fn')");
	if($ins)
	{
	
	$message="Dear $name, Register No.: $regno, Password: $pass";
	echo '<iframe src="http://iotcloud.co.in/testmail/testmail1.php?message='.$message.'&subject=Student Details&email='.$email.'" style="display:none"></iframe>';
	
	$msg="Student Details Added Sucessfully";
	?>
	
	<script>
	//alert("Student Details Added Sucessfully");
//Using setTimeout to execute a function after 5 seconds.
setTimeout(function () {
   //Redirect with JavaScript
   window.location.href= 'admin.php';
}, 5000);
</script>
	<?php
	}
	else
	{
	?>
	<script language="javascript">
	alert("Register No. Already Exist!");
	</script>
	<?php
	}
}
////////////////////////
if($act=="del")
{
mysqli_query($connect,"delete from vir_student where id=$did");
	?>
	<script language="javascript">
	alert("Deleted Sucessfully");
	window.location.href="admin.php";
	</script>
	<?php
}
?>
<html>
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title><?php include("title.php"); ?></title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- site icon -->
      <link rel="icon" href="images/fevicon.png" type="image/png" />
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css" />
      <!-- site css -->
      <link rel="stylesheet" href="style.css" />
      <!-- responsive css -->
      <link rel="stylesheet" href="css/responsive.css" />
      <!-- color css -->
      <link rel="stylesheet" href="css/colors.css" />
      <!-- select bootstrap -->
      <link rel="stylesheet" href="css/bootstrap-select.css" />
      <!-- scrollbar css -->
      <link rel="stylesheet" href="css/perfect-scrollbar.css" />
      <!-- custom css -->
      <link rel="stylesheet" href="css/custom.css" />
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->
<script language="javascript">
function del()
{
	if(!confirm("Are you sure want to Delete?"))
	{
	return false;
	}
	return true;
}
            function validate()
            {
			  
                if (document.form1.name.value == "")
                {
                    alert("Enter the Name");
                    document.form1.name.focus();
                    return false;
                }
				var name=document.form1.name;
			    var letters = /^[A-Za-z. ]+$/;  
				if(name.value.match(letters))  
				{  
				//return true;  
				}  
				else  
				{  
				alert('Username must have alphabet characters only');  
				document.form1.name.select();  
				return false;  
				}
				if (document.form1.regno.value == "")
                {
                    alert("Enter the Register No.");
                    document.form1.regno.focus();
                    return false;
                }
				if (document.form1.mobile.value == "")
                {
                    alert("Enter the Mobile No.");
                    document.form1.mobile.focus();
                    return false;
                }
				if (isNaN(document.form1.mobile.value))
                {
                    alert("Invalid Mobile No.");
                    document.form1.mobile.select();
                    return false;
                }
				if (document.form1.mobile.value.length != 10)
                {
                    alert("10 digists only allowed!!");
                    document.form1.mobile.select();
                    return false;
                }
                if (document.form1.email.value == "")
                {
                    alert("Enter the E-mail");
                    document.form1.email.focus();
                    return false;
                }
				if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(document.form1.email.value))  
				  {  
					//return (true)  
				  }  
				  else
				  {
					alert("You have entered an invalid email address!");
					document.form1.email.select();
					return false; 
				  }
               if (document.form1.dept.selectedIndex == 0)
                {
                    alert("Select the Department");
                    document.form1.dept.focus();
                    return false;
                }
				
				return true;
				}
				</script>
				
   </head>
   <body class="dashboard dashboard_1">
      <div class="full_container">
         <div class="inner_container">
            <!-- Sidebar  -->
            <nav id="sidebar">
               <div class="sidebar_blog_1">
                  <div class="sidebar-header">
                     <div class="logo_section">
                        <a href=""><img class="logo_icon img-responsive" src="images/logo/logo_icon.png" alt="#" /></a>
                     </div>
                  </div>
                  <div class="sidebar_user_info">
                     <div class="icon_setting"></div>
                     <div class="user_profle_side">
                        <div class="user_img"><img class="img-responsive" src="images/logo/logo_icon.png" alt="#" /></div>
                        <div class="user_info">
                           <h6>Admin</h6>
                           <p><span class="online_animation"></span> Online</p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="sidebar_blog_2">
                  <h4>General</h4>
                 <?php include("link_admin.php"); ?>
               </div>
            </nav>
            <!-- end sidebar -->
            <!-- right content -->
            <div id="content">
               <!-- topbar -->
               <div class="topbar">
                  <nav class="navbar navbar-expand-lg navbar-light">
                     <div class="full">
                        <button type="button" id="sidebarCollapse" class="sidebar_toggle"><i class="fa fa-bars"></i></button>
                        <div class="logo_section">
                           <a href="index.html"><img class="img-responsive" src="images/logo/logo.png" alt="#" /></a>
                        </div>
                        <div class="right_topbar">
                           <div class="icon_info">
                              
                              <ul class="user_profile_dd">
                                 <li>
                                    <a class="dropdown-toggle" data-toggle="dropdown"><img class="img-responsive rounded-circle" src="images/logo/logo_icon.png" alt="#" /><span class="name_user">Admin</span></a>
                                    <div class="dropdown-menu">
                                       
                                       <a class="dropdown-item" href="logout.php"><span>Log Out</span> <i class="fa fa-sign-out"></i></a>
                                    </div>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </nav>
               </div>
               <!-- end topbar -->
               <!-- dashboard inner -->
               <div class="midde_cont">
                  <div class="container-fluid">
                     <div class="row column_title">
                        <div class="col-md-12">
                           <div class="page_title">
                              <h2>Dashboard</h2>
                           </div>
                        </div>
                     </div>
                     <div class="row column1">
                        <div class="col-md-6 col-lg-3">
                           <div class="full counter_section margin_bottom_30">
                              <div class="couter_icon">
                                 <div> 
                                    <i class="fa fa-user yellow_color"></i>
                                 </div>
                              </div>
                              <div class="counter_no">
                                 <div>
                                    
                                    <p class="head_couter"><a href="admin.php">Students</a></p>
                                 </div>
                              </div>
                           </div>
                        </div>
						<div class="col-md-6 col-lg-3">
                           <div class="full counter_section margin_bottom_30">
                              <div class="couter_icon">
                                 <div> 
                                    <i class="fa fa-user yellow_color"></i>
                                 </div>
                              </div>
                              <div class="counter_no">
                                 <div>
                                    
                                    <p class="head_couter"><a href="add_staff.php">Staff</a></p>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-6 col-lg-3">
                           <div class="full counter_section margin_bottom_30">
                              <div class="couter_icon">
                                 <div> 
                                    <i class="fa fa-clock-o blue1_color"></i>
                                 </div>
                              </div>
                              <div class="counter_no">
                                 <div>
                                    
                                    <p class="head_couter"><a href="view_lab.php">Lab Time</a></p>
                                 </div>
                              </div>
                           </div>
                        </div>
                        
                        <div class="col-md-6 col-lg-3">
                           <div class="full counter_section margin_bottom_30">
                              <div class="couter_icon">
                                 <div> 
                                    <i class="fa fa-comments-o red_color"></i>
                                 </div>
                              </div>
                              <div class="counter_no">
                                 <div>
                                    <p class="head_couter"><a href="view_result.php">Test Result</a></p>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="row column1 social_media_section">
                        
                        
                     </div>
                     <!-- graph -->
                    
                     <!-- end graph -->
                     <div class="row column3">
                        <!-- testimonial -->
                        
                        <!-- end testimonial -->
                        <!-- progress bar -->
                        
                        <!-- end progress bar -->
                     </div>
                     <div class="row column4 graph">
                        <div class="col-md-6 margin_bottom_30">
                           <div class="dash_blog">
                              <div class="dash_blog_inner">
                                 <div class="dash_head">
                                    <h3><span><i class="fa fa-calendar"></i> Add New Student</span><span class="plus_green_bt"><a href="#">+</a></span></h3>
                                 </div>
                                 <div class="list_cont">
                                    
                                 </div>
                                 <div class="task_list_main">
                                    <form name="form1" class="contact-form" method="post" enctype="multipart/form-data">
									<?php
									if($msg!="")
									{
									?>
									<span style="color:#009933"><?php echo $msg; ?></span>
									<?php
									}
									?>
									<div class="row">
									<div class="col-md-1">
									</div>
									<div class="col-md-10">
							
												
												<!-- form-item -->
												<div class="form-item">
													<input class="form-control" type="text" name="name" placeholder="Name"/>
												</div><!-- End / form-item -->
												
												<br>
												<!-- form-item -->
												<div class="form-item">
													<input class="form-control" type="text" name="regno" placeholder="Register No."/>
												</div><!-- End / form-item -->
												<br>
												<div class="form-item">
													<input class="form-control" type="text" name="mobile" maxlength="10" placeholder="Mobile No."/>
												</div><!-- End / form-item -->
												<br>
												<div class="form-item">
													<input class="form-control" type="text" name="email" placeholder="E-mail"/>
												</div><!-- End / form-item -->
												<br>
												<div class="form-item">
													<select class="form-control" name="dept">
													<option value="">-Department-</option>
													<?php
													$cq=mysqli_query($connect,"select * from vir_department");
													while($cr=mysqli_fetch_array($cq))
													{
													?>
													<option><?php echo $cr['department']; ?></option>
													<?php
													}
													?>
													</select>
												</div><!-- End / form-item --><br>
												<div class="form-item">
												<label>Student Photo</label>
												<input class="form-control" type="file" name="file" placeholder="Photo"/>
												</div>
												<br>
												<button class="main_bt read_bt" type="submit" name="btn" onClick="return validate()">Add</button>
												</div>
												</div>
											</form>
                                 </div>
                                
                              </div>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="dash_blog">
                              <div class="dash_blog_inner">
                                 <div class="dash_head">
                                    <h3><span><i class="fa fa-comments-o"></i> Student</span></h3>
                                 </div>
                                 <div class="list_cont">
                                    <p>Information</p>
                                 </div>
                                 <div class="msg_list_main">
                                    <ul class="msg_list">
									<form name="form2" class="contact-form" method="post">
					<div class="row">
							<div class="col-lg-1">
							</div>
							<div class="col-lg-3">
							
							<select class="form-control" name="dept2">
							<?php
							$cq2=mysqli_query($connect,"select * from vir_department");
							while($cr2=mysqli_fetch_array($cq2))
							{
							?>
							<option <?php if($cr2['department']==$dept2) echo "selected"; ?>><?php echo $cr2['department']; ?></option>
							<?php
							}
							?>
							</select>
							</div>
							

							<div class="col-lg-3">
							<button class="btn btn-primary btn-round mb-30" type="submit" name="btn2">Go</button>
							</div>
						</div>
							</form>
									<?php
									
								if($dept2!="")
								{
								$q=" where department='$dept2'"; 
								}
									$q1=mysqli_query($connect,"select * from vir_student $q");
									while($r1=mysqli_fetch_array($q1))
									{
									?>
                                       <li>
									   <?php
									   if($r1['photo']!="")
									   {
									   ?> <span><img src="photo/<?php echo $r1['photo']; ?>" class="img-responsive" alt="#" /></span><?php
									   }
									   else
									   {
									   ?>
                                          <span><img src="images/proimg.jpg" class="img-responsive" alt="#" /></span>
                                         <?php
										 }
										 ?>
										  <span>
                                          <span class="name_user"><?php echo $r1['regno'].": ".$r1['name']." [".$r1['department']."]"; ?></span>
										  <span class="msg_user"><i class="fa fa-phone"></i> : <?php echo $r1['mobile']; ?></span><br>
                                          <span class="msg_user"><i class="fa fa-envelope-o"></i> : <?php echo $r1['email']; ?></span>
										  <br><span><a href="view_att.php?regno=<?php echo $r1['regno']; ?>">Attendance</a></span>
                                          <span class="time_ago">
										  <a href="view_result.php?regno=<?php echo $r1['regno']; ?>">Result</a> /
										  <a href="edit.php?sid=<?php echo $r1['id']; ?>">Edit</a> / <a href="admin.php?act=del&did=<?php echo $r1['id']; ?>" onClick="return del()">Delete</a></span>
                                          </span>
                                       </li>
                                      <?php
									 } 
									
									  ?> 
                                    </ul>
                                 </div>
                                <!-- <div class="read_more">
                                    <div class="center"><a class="main_bt read_bt" href="#">Read More</a></div>
                                 </div>-->
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <!-- footer -->
                  <div class="container-fluid">
                     <div class="footer">
                        <p><?php include("title1.php"); ?>
                            <a href="https://themewagon.com/"></a>
                        </p>
                     </div>
                  </div>
               </div>
               <!-- end dashboard inner -->
            </div>
         </div>
      </div>
      <!-- jQuery -->
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <!-- wow animation -->
      <script src="js/animate.js"></script>
      <!-- select country -->
      <script src="js/bootstrap-select.js"></script>
      <!-- owl carousel -->
      <script src="js/owl.carousel.js"></script> 
      <!-- chart js -->
      <script src="js/Chart.min.js"></script>
      <script src="js/Chart.bundle.min.js"></script>
      <script src="js/utils.js"></script>
      <script src="js/analyser.js"></script>
      <!-- nice scrollbar -->
      <script src="js/perfect-scrollbar.min.js"></script>
      <script>
         var ps = new PerfectScrollbar('#sidebar');
      </script>
      <!-- custom js -->
      <script src="js/custom.js"></script>
      <script src="js/chart_custom_style1.js"></script>
   </body>
</html>