<?php
session_start();
include("dbconnect.php");
extract($_REQUEST);
$uname=$_SESSION['uname'];
$current="";
$answer="";

$qry=mysqli_query($connect,"select * from vir_student where regno='$uname'");
$row=mysqli_fetch_array($qry);
$dept=$row['department'];

/*if(!empty($_POST))
{
	$current=$_POST['cppcode'];
	$file="PalindromeExample.java";
	file_put_contents($file, $current);
	
	putenv("PATH=C:\Program Files (x86)\Java\jdk1.7.0_65\bin");
	
	shell_exec("javac PalindromeExample.java");//compile
	
	$answer=shell_exec("java PalindromeExample");//compile
	
	//$answer=shell_exec("javapgm.exe");
}*/
/////////////////
if($fid!="")
{
	$fq=mysqli_query($connect,"select * from vir_program where regno='$uname' && id=$fid");
	$fr=mysqli_fetch_array($fq);
	$fn2=$fr['filename'];
	$ss=explode(".",$fn2);
	
	$cc="";
	if($fname=="")
	{
	$fname=$ss[0];
		$xn=file("program/$uname/$fn2");
		foreach($xn as $xnn)
		{
		$cc.=$xnn;
		}
		
		$cppcode=$cc;
	}
}
?>
<style>
.txtarea {
resize: none;
outline:none;
width:500px;
height:500px;
border: 3px solid #cccccc;
padding: 5px;
font-family:Arial, Helvetica, sans-serif;
background-position:bottom right;
background-repeat:no-repeat;
font-size:14px;
color:#000000;


}
</style>
<form method="post">
<table border="0">
<tr>
<td>
	<textarea name="cppcode" style="background:#FFFFFF;" placeholder="Enter Java code" class="txtarea"><?php  echo $cppcode; ?></textarea>
<br />
	<input type="text" name="fname" value="<?php echo $fname; ?>" required />.java
	<select name="labpgm">
	<option value="">-Lab Program-</option>
	<?php
	$i=0;
	$cq=mysqli_query($connect,"select * from vir_assign where dept='$dept' && language='Java'");
	while($cr=mysqli_fetch_array($cq))
	{
	$i++;
	?>
	<option value="<?php echo $cr['id']; ?>"><?php echo "Program".$i; ?></option>
	<?php
	}
	?>
	</select>
	<input type="submit" name="btn2" value="Save" />
	<?php
	if(isset($btn2))
	{
	
	$fn=$fname.".java";
	$fp=fopen("program/$uname/$fn","w");
	fwrite($fp,$cppcode);
	////////////////
	$current=$_POST['cppcode'];
	$file=$fn;
	file_put_contents("program/$uname/$file", $current);
	
	putenv("PATH=C:\Program Files (x86)\Java\jdk1.7.0_65\bin");
	chdir("program/$uname/");
	shell_exec("javac $fn");//compile
	
	$answer=shell_exec("java $fname");//compile
	
		/////////////////////
		$q4=mysqli_query($connect,"select * from vir_program where regno='$uname' && filename='$fn'");
		$n4=mysqli_num_rows($q4);
		if($n4==0)
		{
		$mq=mysqli_query($connect,"select max(id) from vir_program");
		$mr=mysqli_fetch_array($mq);
		$id=$mr['max(id)']+1;
		mysqli_query($connect,"insert into vir_program(id,regno,language,filename,lab_id) values($id,'$uname','Java','$fn','$labpgm')");
		}
		else
		{
		mysqli_query($connect,"update vir_program set lab_id='$labpgm' where regno='$uname' && filename='$fn'");
		}
		////////////////////
	echo "File Saved";
	}
	?>
	<br />
	<br />
	<input type="submit" value="Save and Run" name="btn" />
</td>
<td>
	
<?php
	
	if(isset($btn))
	{
		if($fname=="")
		{
		$fname="sample";
		}
	$fn=$fname.".java";
	$fp=fopen("program/$uname/$fn","w");
	fwrite($fp,$cppcode);
	/////////////////////
	$current=$_POST['cppcode'];
	$file=$fn;
	file_put_contents("program/$uname/$file", $current);
	
	putenv("PATH=C:\Program Files (x86)\Java\jdk1.7.0_65\bin");
	chdir("program/$uname/");
	shell_exec("javac $fn");//compile
	
	$answer=shell_exec("java $fname");//compile
	//////////////////////////////////////////////
	
		$q4=mysqli_query($connect,"select * from vir_program where regno='$uname' && filename='$fn'");
		$n4=mysqli_num_rows($q4);
		if($n4==0)
		{
		$mq=mysqli_query($connect,"select max(id) from vir_program");
		$mr=mysqli_fetch_array($mq);
		$id=$mr['max(id)']+1;
		mysqli_query($connect,"insert into vir_program(id,regno,language,filename,lab_id) values($id,'$uname','Java','$fn','$labpgm')");
		}
		else
		{
		mysqli_query($connect,"update vir_program set lab_id='$labpgm' where regno='$uname' && filename='$fn'");
		}
		////////////////////
	
	?>
	<textarea name="cppcode2" style="background:#99CCFF;" placeholder="See Result" class="txtarea"><?php  echo $answer; ?></textarea>
<?php
	}
	?>
</td>
</tr>
</table>
</form>
