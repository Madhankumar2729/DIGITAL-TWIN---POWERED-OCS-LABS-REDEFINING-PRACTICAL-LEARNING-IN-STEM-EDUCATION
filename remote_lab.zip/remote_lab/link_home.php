<div class="dropdown-menu">
                                       <a class="dropdown-item" href="index.php">Student</a>
									   <a class="dropdown-item" href="login_lab.php">Lab In-Charge</a>
                                       <a class="dropdown-item" href="login_staff.php">Staff</a>
									   <a class="dropdown-item" href="login.php">College Admin</a>
                                       <!--<a class="dropdown-item" href="help.html">Help</a>
                                       <a class="dropdown-item" href="#"><span>Log Out</span> <i class="fa fa-sign-out"></i></a>-->
                                    </div>