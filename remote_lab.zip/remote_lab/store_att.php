<?php
session_start();
include("dbconnect.php");
extract($_REQUEST);
$msg="";
$uname=$_SESSION['uname'];

$qry=mysqli_query($connect,"select * from vir_student where regno='$uname'");
$row=mysqli_fetch_array($qry);
$dept=$row['department'];

$rdate=date("d-m-Y");
$dy=date("l");
$ch1=mktime(date('H')+5,date('i')+30,date('s'));
$rh=date('H',$ch1);
$rm=date('i',$ch1);
$rtime="$rh:$rm";
$mon=date("m");
$yr=date("Y");

mysqli_query($connect,"update vir_attendance set rtime2='$rtime',seconds=seconds+5 where regno='$uname' && rdate='$rdate' && time_id='$rid'");



?>  <script>
//Using setTimeout to execute a function after 5 seconds.
setTimeout(function () {
   //Redirect with JavaScript
   window.location.href= 'store_att.php?rid=<?php echo $rid; ?>';
}, 5000);
</script>
