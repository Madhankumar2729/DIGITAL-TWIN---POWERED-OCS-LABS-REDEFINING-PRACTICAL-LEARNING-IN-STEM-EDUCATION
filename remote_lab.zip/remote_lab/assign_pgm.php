<?php
include("protect3.php");
include("dbconnect.php");
extract($_REQUEST);
$msg="";
$uname=$_SESSION['labname'];

if(isset($btn))
{
	for($i=0;$i<count($qc);$i++)
	{
$mq=mysqli_query($connect,"select max(id) from vir_assign");
$mr=mysqli_fetch_array($mq);
$id=$mr['max(id)']+1;
$pass=rand(10000,99999);

$result="q".$id.".txt";
	$ins=mysqli_query($connect,"insert into vir_assign(id,qid,language,dept) values($id,'$qc[$i]','$language','$dept')");
	}
	
	
	if($ins)
	{

	?>
	<script language="javascript">
	alert("Assigned Sucessfully");
	window.location.href="assign_pgm.php";
	</script>
	<?php
	}
	
}
///////////////////////////
if($act=="del")
{
mysqli_query($connect,"delete from vir_assign where id=$did");
?>
<script language="javascript">
window.location.href="assign_pgm.php";
</script>
<?php
}
?>
<html>
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Virtual Lab</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- site icon -->
      <link rel="icon" href="images/fevicon.png" type="image/png" />
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css" />
      <!-- site css -->
      <link rel="stylesheet" href="style.css" />
      <!-- responsive css -->
      <link rel="stylesheet" href="css/responsive.css" />
      <!-- color css -->
      <link rel="stylesheet" href="css/colors.css" />
      <!-- select bootstrap -->
      <link rel="stylesheet" href="css/bootstrap-select.css" />
      <!-- scrollbar css -->
      <link rel="stylesheet" href="css/perfect-scrollbar.css" />
      <!-- custom css -->
      <link rel="stylesheet" href="css/custom.css" />
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->
<script language="javascript">
function del()
{
	if(!confirm("Are you sure want to Delete?"))
	{
	return false;
	}
	return true;
}

           
				</script>
				
   </head>
   <body class="dashboard dashboard_1">
      <div class="full_container">
         <div class="inner_container">
            <!-- Sidebar  -->
            <nav id="sidebar">
               <div class="sidebar_blog_1">
                  <div class="sidebar-header">
                     <div class="logo_section">
                        <a href=""><img class="logo_icon img-responsive" src="images/logo/logo_icon.png" alt="#" /></a>
                     </div>
                  </div>
                  <div class="sidebar_user_info">
                     <div class="icon_setting"></div>
                     <div class="user_profle_side">
                        <div class="user_img"><img class="img-responsive" src="images/logo/logo_icon.png" alt="#" /></div>
                        <div class="user_info">
                           <h6>Lab IN-Charge</h6>
                           <p><span class="online_animation"></span> Online</p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="sidebar_blog_2">
                  <h4>General</h4>
                  <ul class="list-unstyled components">
				  	<li><a href="lab_home.php"><i class="fa fa-dashboard yellow_color"></i> <span>Dashboard</span></a></li>
                    
					 <li><a href="view_program.php"><i class="fa fa-diamond purple_color"></i> <span>Load Programs</span></a></li>
					 
					 <li><a href="assign_pgm.php"><i class="fa fa-diamond purple_color"></i> <span>Assign Programs</span></a></li>
                    
					<li><a href="view_execute.php"><i class="fa fa-diamond purple_color"></i> <span>View Executed Programs</span></a></li>
                     
                     <li><a href="logout.php"><i class="fa fa-briefcase blue1_color"></i> <span>Logout</span></a></li>
                     <!--<li>
                        <a href="contact.html">
                        <i class="fa fa-paper-plane red_color"></i> <span>Contact</span></a>
                     </li>-->
                     <!--<li class="active">
                        <a href="#additional_page" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-clone yellow_color"></i> <span>Additional Pages</span></a>
                        <ul class="collapse list-unstyled" id="additional_page">
                           <li>
                              <a href="profile.html">> <span>Profile</span></a>
                           </li>
                           <li>
                              <a href="project.html">> <span>Projects</span></a>
                           </li>
                           <li>
                              <a href="login.html">> <span>Login</span></a>
                           </li>
                           <li>
                              <a href="404_error.html">> <span>404 Error</span></a>
                           </li>
                        </ul>
                     </li>
                     <li><a href="map.html"><i class="fa fa-map purple_color2"></i> <span>Map</span></a></li>
                     <li><a href="charts.html"><i class="fa fa-bar-chart-o green_color"></i> <span>Charts</span></a></li>
                     <li><a href="settings.html"><i class="fa fa-cog yellow_color"></i> <span>Settings</span></a></li>-->
                  </ul>
               </div>
            </nav>
            <!-- end sidebar -->
            <!-- right content -->
            <div id="content">
               <!-- topbar -->
               <div class="topbar">
                  <nav class="navbar navbar-expand-lg navbar-light">
                     <div class="full">
                        <button type="button" id="sidebarCollapse" class="sidebar_toggle"><i class="fa fa-bars"></i></button>
                        <div class="logo_section">
                           <a href="index.html"><img class="img-responsive" src="images/logo/logo.png" alt="#" /></a>
                        </div>
                        <div class="right_topbar">
                           <div class="icon_info">
                              
                              <ul class="user_profile_dd">
                                 <li>
                                    <a class="dropdown-toggle" data-toggle="dropdown"><img class="img-responsive rounded-circle" src="images/logo/logo_icon.png" alt="#" /><span class="name_user">Lab IN-Charge</span></a>
                                    <div class="dropdown-menu">
                                       
                                       <a class="dropdown-item" href="logout.php"><span>Log Out</span> <i class="fa fa-sign-out"></i></a>
                                    </div>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </nav>
               </div>
               <!-- end topbar -->
               <!-- dashboard inner -->
               <div class="midde_cont">
                  <div class="container-fluid">
                     <div class="row column_title">
                        <div class="col-md-12">
                           <div class="page_title">
                              <h2>Lab Program</h2>
                           </div>
                        </div>
                     </div>
                     <div class="row column1">
                        
                     </div>
                     <div class="row column1 social_media_section">
                        
                        
                     </div>
                     <!-- graph -->
                    
                     <!-- end graph -->
                     <div class="row column3">
                        <!-- testimonial -->
                        
                        <!-- end testimonial -->
                        <!-- progress bar -->
                        
                        <!-- end progress bar -->
                     </div>
                     <div class="row column4 graph">
                        <div class="col-md-6 margin_bottom_30">
                           <div class="dash_blog">
                              <div class="dash_blog_inner">
                                 <div class="dash_head">
                                    <h3><span><i class="fa fa-calendar"></i> Assign Program</span><span class="plus_green_bt"><a href="#">+</a></span></h3>
                                 </div>
                                 <div class="list_cont">
                                    
                                 </div>
                                 <div class="task_list_main">
                                    <form name="form1" class="contact-form" method="post" enctype="multipart/form-data">
									
									<div class="row">
									<div class="col-md-1">
									</div>
									<div class="col-md-10">
							
												
												<!-- form-item -->
												
												
												<div class="form-item">
													<select class="form-control" name="dept" required>
													<option value="">-Department-</option>
													<?php
													$cq=mysqli_query($connect,"select * from vir_department");
													while($cr=mysqli_fetch_array($cq))
													{
													?>
													<option <?php if($cr['department']==$dept) echo "selected"; ?>><?php echo $cr['department']; ?></option>
													<?php
													}
													?>
													</select>
												</div><!-- End / form-item -->
												<br>
												<div class="form-item">
													<select name="language" class="form-control" onChange="this.form.submit()" required>
													<option value="">-Language-</option>
													<option <?php if($language=="C Program") echo "selected"; ?>>C Program</option>
													<option <?php if($language=="CPP") echo "selected"; ?>>CPP</option>
													<option <?php if($language=="Java") echo "selected"; ?>>Java</option>
													<option <?php if($language=="PHP") echo "selected"; ?>>PHP</option>
													</select>
												</div><!-- End / form-item -->
												<!-- form-item -->
												
												</div>
												</div>
												
												
												<?php
												if($language!="")
												{
												?>
												<div style="width:90%; height:300px; padding:10px; overflow:auto">
												<?php
												
													$qq1=mysqli_query($connect,"select * from vir_question where language='$language'");
													while($rr1=mysqli_fetch_array($qq1))
													{
													echo '<input type="checkbox" name="qc[]" value="'.$rr1['id'].'">';
													echo $rr1['question']."<br>";
													}
												
												
												?>
												</div>
												
												
												<button class="main_bt read_bt" type="submit" name="btn" onClick="return validate()">Add</button>
												<?php
												}
												?>
											</form>
											
											
											
											
											
											
											
                                 </div>
                                
                              </div>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="dash_blog">
                              <div class="dash_blog_inner">
                                 <div class="dash_head">
                                    <h3><span><i class="fa fa-comments-o"></i> Program</span></h3>
                                 </div>
                                 <div class="list_cont">
                                    <p>Assigned</p>
                                 </div>
                                 <div class="msg_list_main">
                                    <ul class="msg_list">
									
									<form name="form1" class="contact-form" method="post">
					<div class="row">
							<div class="col-lg-3">
							<select class="form-control" name="dept2" required>
													<option value="">-Department-</option>
													<?php
													$cq2=mysqli_query($connect,"select * from vir_department");
													while($cr2=mysqli_fetch_array($cq2))
													{
													?>
													<option <?php if($cr2['department']==$dept2) echo "selected"; ?>><?php echo $cr2['department']; ?></option>
													<?php
													}
													?>
													</select>
							</div>
							<div class="col-lg-3">
							
							<select class="form-control" name="language2">
							<option value="">-Select Language-</option>
							<option <?php if($language2=="C Program") echo "selected"; ?>>C Program</option>
							<option <?php if($language2=="CPP") echo "selected"; ?>>CPP</option>
							<option <?php if($language2=="Java") echo "selected"; ?>>Java</option>
							<option <?php if($language2=="PHP") echo "selected"; ?>>PHP</option>
							</select>
							</div>
							<div class="col-lg-3">
							<button class="btn btn-primary btn-round mb-30" type="submit" name="btn2">Go</button>
							</div>
						</div>
							</form>
									<?php
							if(isset($btn2))
							{
								if($language2!="")
								{
								$qry1=mysqli_query($connect,"select * from vir_assign where language='$language2' && dept='$dept2'");
								}
								
							$num1=mysqli_num_rows($qry1);
							if($num1>0)
							{
							$i=0;
							while($row1=mysqli_fetch_array($qry1))
							{
							$i++;
							$qry2=mysqli_query($connect,"select * from vir_question where id='".$row1['qid']."'");
							$row2=mysqli_fetch_array($qry2);
							?>	
                                       <li>
									  
										  <span>
                                          <span class="name_user"><?php echo $i.".".$row2['question']; ?></span><br>
                                          <span class="msg_user"><?php echo "Language: ".$row2['language']; ?></span><br>
										  <span class="msg_user"><?php echo "Lines: ".$row2['min_lines']." to ".$row2['max_lines']; ?></span><br>
							 <span class="msg_user">Output Format: <br><?php
							$fn=$row2['result'];
							$x=file("upload/$fn");
							foreach($x as $x1)
							{
							echo $x1."<br>";
							}
							?></span><br>
							<span class="msg_user"><?php echo "Keywords: ".$row2['keywords']; ?></span><br>
                                          <span class="time_ago"><?php echo '<a href="assign_pgm.php?act=del&did='.$row1['id'].'" onclick="return del()">Delete</a>'; ?></span>
                                          </span>
                                       </li>
                                    <?php
									}
								}
								else
								{
								echo "Empty Result!!";
								}
							}
							?>
                                    </ul>
                                 </div>
                                 <!--<div class="read_more">
                                    <div class="center"><a class="main_bt read_bt" href="#">Read More</a></div>
                                 </div>-->
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <!-- footer -->
                  <div class="container-fluid">
                     <div class="footer">
                        <p>Virtual Lab
                            <a href="https://themewagon.com/"></a>
                        </p>
                     </div>
                  </div>
               </div>
               <!-- end dashboard inner -->
            </div>
         </div>
      </div>
      <!-- jQuery -->
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <!-- wow animation -->
      <script src="js/animate.js"></script>
      <!-- select country -->
      <script src="js/bootstrap-select.js"></script>
      <!-- owl carousel -->
      <script src="js/owl.carousel.js"></script> 
      <!-- chart js -->
      <script src="js/Chart.min.js"></script>
      <script src="js/Chart.bundle.min.js"></script>
      <script src="js/utils.js"></script>
      <script src="js/analyser.js"></script>
      <!-- nice scrollbar -->
      <script src="js/perfect-scrollbar.min.js"></script>
      <script>
         var ps = new PerfectScrollbar('#sidebar');
      </script>
      <!-- custom js -->
      <script src="js/custom.js"></script>
      <script src="js/chart_custom_style1.js"></script>
   </body>
</html>