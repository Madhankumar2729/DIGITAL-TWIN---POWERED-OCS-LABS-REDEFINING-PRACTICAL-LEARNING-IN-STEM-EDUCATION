<?php
session_start();
include("dbconnect.php");
extract($_REQUEST);
$msg="";

?>
<html>
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Virtual Lab</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- site icon -->
      <link rel="icon" href="images/fevicon.png" type="image/png" />
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css" />
      <!-- site css -->
      <link rel="stylesheet" href="style.css" />
      <!-- responsive css -->
      <link rel="stylesheet" href="css/responsive.css" />
      <!-- color css -->
      <link rel="stylesheet" href="css/colors.css" />
      <!-- select bootstrap -->
      <link rel="stylesheet" href="css/bootstrap-select.css" />
      <!-- scrollbar css -->
      <link rel="stylesheet" href="css/perfect-scrollbar.css" />
      <!-- custom css -->
      <link rel="stylesheet" href="css/custom.css" />
	  <style>
.txtarea {
resize: none;
outline:none;
width:500px;
height:500px;
border: 3px solid #cccccc;
padding: 5px;
font-family:Arial, Helvetica, sans-serif;
background-position:bottom right;
background-repeat:no-repeat;
font-size:14px;
color:#000000;

}
</style>
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->
<script language="javascript">
function del()
{
	if(!confirm("Are you sure want to Delete?"))
	{
	return false;
	}
	return true;
}

            function validate()
            {
			  
                if (document.form1.name.value == "")
                {
                    alert("Enter the Name");
                    document.form1.name.focus();
                    return false;
                }
				var name=document.form1.name;
			    var letters = /^[A-Za-z. ]+$/;  
				if(name.value.match(letters))  
				{  
				//return true;  
				}  
				else  
				{  
				alert('Username must have alphabet characters only');  
				document.form1.name.select();  
				return false;  
				}
				if (document.form1.regno.value == "")
                {
                    alert("Enter the Register No.");
                    document.form1.regno.focus();
                    return false;
                }
				if (document.form1.mobile.value == "")
                {
                    alert("Enter the Mobile No.");
                    document.form1.mobile.focus();
                    return false;
                }
				if (isNaN(document.form1.mobile.value))
                {
                    alert("Invalid Mobile No.");
                    document.form1.mobile.select();
                    return false;
                }
				if (document.form1.mobile.value.length != 10)
                {
                    alert("10 digists only allowed!!");
                    document.form1.mobile.select();
                    return false;
                }
                if (document.form1.email.value == "")
                {
                    alert("Enter the E-mail");
                    document.form1.email.focus();
                    return false;
                }
				if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(document.form1.email.value))  
				  {  
					//return (true)  
				  }  
				  else
				  {
					alert("You have entered an invalid email address!");
					document.form1.email.select();
					return false; 
				  }
               if (document.form1.dept.selectedIndex == 0)
                {
                    alert("Select the Department");
                    document.form1.dept.focus();
                    return false;
                }
				
				return true;
				}
				</script>
				
   </head>
   <body class="dashboard dashboard_1">
      <div class="full_container">
         <div class="inner_container">
            <!-- Sidebar  -->
            <nav id="sidebar">
               <div class="sidebar_blog_1">
                  <div class="sidebar-header">
                     <div class="logo_section">
                        <a href=""><img class="logo_icon img-responsive" src="images/logo/logo_icon.png" alt="#" /></a>
                     </div>
                  </div>
                  <div class="sidebar_user_info">
                     <div class="icon_setting"></div>
                     <div class="user_profle_side">
                        <div class="user_img"><img class="img-responsive" src="images/logo/logo_icon.png" alt="#" /></div>
                        <div class="user_info">
                           <h6>Staff</h6>
                           <p><span class="online_animation"></span> Online</p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="sidebar_blog_2">
                  <h4>General</h4>
                  <ul class="list-unstyled components">
				  	<li><a href="staff_home.php"><i class="fa fa-dashboard yellow_color"></i> <span>Dashboard</span></a></li>
                     <!--<li class="active">
                        <a href="#dashboard" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-dashboard yellow_color"></i> <span>Dashboard</span></a>
                        <ul class="collapse list-unstyled" id="dashboard">
                           <li>
                              <a href="dashboard.html">> <span>Default Dashboard</span></a>                           </li>
                           <li>
                              <a href="dashboard_2.html">> <span>Dashboard style 2</span></a>                           </li>
                        </ul>
                     </li>-->
                     <li><a href="view_result1.php"><i class="fa fa-table purple_color2"></i> <span>Report</span></a></li>
                     <li><a href="logout.php"><i class="fa fa-briefcase blue1_color"></i> <span>Logout</span></a></li>
                     <!--<li><a href="tables.html"><i class="fa fa-table purple_color2"></i> <span>Tables</span></a></li>
                     <li>
                        <a href="#apps" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-object-group blue2_color"></i> <span>Apps</span></a>
                        <ul class="collapse list-unstyled" id="apps">
                           <li><a href="email.html">> <span>Email</span></a></li>
                           <li><a href="calendar.html">> <span>Calendar</span></a></li>
                           <li><a href="media_gallery.html">> <span>Media Gallery</span></a></li>
                        </ul>
                     </li>
                     <li><a href="price.html"><i class="fa fa-briefcase blue1_color"></i> <span>Pricing Tables</span></a></li>
                     <li>
                        <a href="contact.html">
                        <i class="fa fa-paper-plane red_color"></i> <span>Contact</span></a>
                     </li>
                     <li class="active">
                        <a href="#additional_page" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-clone yellow_color"></i> <span>Additional Pages</span></a>
                        <ul class="collapse list-unstyled" id="additional_page">
                           <li>
                              <a href="profile.html">> <span>Profile</span></a>
                           </li>
                           <li>
                              <a href="project.html">> <span>Projects</span></a>
                           </li>
                           <li>
                              <a href="login.html">> <span>Login</span></a>
                           </li>
                           <li>
                              <a href="404_error.html">> <span>404 Error</span></a>
                           </li>
                        </ul>
                     </li>
                     <li><a href="map.html"><i class="fa fa-map purple_color2"></i> <span>Map</span></a></li>
                     <li><a href="charts.html"><i class="fa fa-bar-chart-o green_color"></i> <span>Charts</span></a></li>
                     <li><a href="settings.html"><i class="fa fa-cog yellow_color"></i> <span>Settings</span></a></li>-->
                  </ul>
               </div>
            </nav>
            <!-- end sidebar -->
            <!-- right content -->
            <div id="content">
               <!-- topbar -->
               <div class="topbar">
                  <nav class="navbar navbar-expand-lg navbar-light">
                     <div class="full">
                        <button type="button" id="sidebarCollapse" class="sidebar_toggle"><i class="fa fa-bars"></i></button>
                        <div class="logo_section">
                           <a href="index.html"><img class="img-responsive" src="images/logo/logo.png" alt="#" /></a>
                        </div>
                        <div class="right_topbar">
                           <div class="icon_info">
                              
                              <ul class="user_profile_dd">
                                 <li>
                                    <a class="dropdown-toggle" data-toggle="dropdown"><img class="img-responsive rounded-circle" src="images/logo/logo_icon.png" alt="#" /><span class="name_user">Staff</span></a>
                                    <div class="dropdown-menu">
                                       
                                       <a class="dropdown-item" href="logout.php"><span>Log Out</span> <i class="fa fa-sign-out"></i></a>
                                    </div>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </nav>
               </div>
               <!-- end topbar -->
               <!-- dashboard inner -->
               <div class="midde_cont">
                  <div class="container-fluid">
                     <div class="row column_title">
                        <div class="col-md-12">
                           <div class="page_title">
                              <h2>Result</h2>
                           </div>
                        </div>
                     </div>
                     <div class="row column1">
                        
                     </div>
                     <div class="row column1 social_media_section">
                        
                        
                     </div>
                     <!-- graph -->
                    
                     <!-- end graph -->
                     <div class="row column3">
                        <!-- testimonial -->
                        
                        <!-- end testimonial -->
                        <!-- progress bar -->
                        
                        <!-- end progress bar -->
                     </div>
                     <div class="row column4 graph">
                        <div class="col-md-6 margin_bottom_30">
                           <div class="dash_blog">
                              <div class="dash_blog_inner">
                                 <div class="dash_head">
                                    <h3><span><i class="fa fa-calendar"></i> Test result</span><span class="plus_green_bt"><a href="#">+</a></span></h3>
                                 </div>
                                 <div class="list_cont">
                                    
                                 </div>
                                 <div class="task_list_main">
                                   
									<div class="row">
									<div class="col-md-1">
									</div>
									<div class="col-md-10">
										 <form name="form1" class="contact-form" method="post">
									
									<div class="row">
									
									<div class="col-md-3">
							
												
												<!-- form-item -->
												<div class="form-item">
													<select class="form-control" name="tid">
													<option value="">-Test-</option>
													<?php
													$cq1=mysqli_query($connect,"select * from vir_test");
													while($cr1=mysqli_fetch_array($cq1))
													{
													?>
													<option value="<?php echo $cr1['id']; ?>" <?php if($cr1['id']==$tid) echo "selected"; ?>><?php echo "Test[".$cr1['id']."]: ".$cr1['language']; ?></option>
													<?php
													}
													?>
													</select>
												</div>
												</div>
												<div class="col-md-3">
												<div class="form-item">
													<select class="form-control" name="dept">
													<option value="">-Department-</option>
													<?php
													$cq=mysqli_query($connect,"select * from vir_department");
													while($cr=mysqli_fetch_array($cq))
													{
													?>
													<option <?php if($cr['department']==$dept) echo "selected"; ?>><?php echo $cr['department']; ?></option>
													<?php
													}
													?>
													</select>
												</div></div><!-- End / form-item -->
												
												<div class="col-md-3">
												<button class="main_bt read_bt" type="submit" name="btn">Go</button>
												</div>
											</div>
											</div>
											
											
											
											<?php
											if($tid!="" && $dept!="")
											{
											
												if($regno!="")
												{
												$q=" && regno='$regno'";
												}
											
											 $qq1=mysqli_query($connect,"select * from vir_result where tid=$tid && dept='$dept' $q");
											 $nn1=mysqli_num_rows($qq1);
											 if($nn1>0)
											 {
										$j=0;
									  while($rr1=mysqli_fetch_array($qq1))
									  {
									  $j++;
									  
									  $q41=mysqli_query($connect,"select * from vir_student where regno='".$rr1['regno']."'");
										$r41=mysqli_fetch_array($q41);
										
										
									  //////////////////
									  $q4=mysqli_query($connect,"select * from vir_test_attend where tid=$tid && regno='".$rr1['regno']."'");
										$n4=mysqli_num_rows($q4);
										if($n4>0)
										{
										$i=0;
										
										?>
										<div class="full price_table padding_infor_info">
										<?php
										echo $r41['regno'].": ".$r41['name'];
										?>
										<div class="row"><?php
										
											while($r4=mysqli_fetch_array($q4))
											{
											$i++;
											$qid=$r4['qid'];
												$q5=mysqli_query($connect,"select * from vir_question where id=$qid");
												$r5=mysqli_fetch_array($q5);
												//echo $i.".".$r5['question']."<br><br>";
												
												$q51=mysqli_query($connect,"select * from vir_test where id=$tid");
												$r51=mysqli_fetch_array($q51);
												?>
												
		<div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 profile_details margin_bottom_30">
                                       <div class="contact_blog">
                                          <h4 class="brief">Program <?php echo $i; ?>:</h4>
                                          <div class="contact_inner">
                                             <div class="left">
                                                <h3><?php echo $lang; ?></h3>
                                                <p><strong></strong><?php echo $r5['question']; ?></p>
												Mark:<br>
												<?php echo $r4['test_mark']; ?> / <?php echo $r51['mark']; ?>
                                                <!--<ul class="list-unstyled">
                                                   <li><i class="fa fa-envelope-o"></i> : test@gmail.com</li>
                                                   <li><i class="fa fa-phone"></i> : 987 654 3210</li>
                                                </ul>-->
                                             </div>
                                             <!--<div class="right">
                                                <div class="profile_contacts">
                                                   <img class="img-responsive" src="images/layout_img/msg2.png" alt="#" />
                                                </div>
                                             </div>-->
                                             <div class="bottom_list">
                                                <!--<div class="left_rating">
                                                   <p class="ratings">
                                                      <a href="#"><span class="fa fa-star"></span></a>
                                                      <a href="#"><span class="fa fa-star"></span></a>
                                                      <a href="#"><span class="fa fa-star"></span></a>
                                                      <a href="#"><span class="fa fa-star"></span></a>
                                                      <a href="#"><span class="fa fa-star-o"></span></a>
                                                   </p>
                                                </div>-->
                                                <div class="right_button">
                                                   <!--<button type="button" class="btn btn-success btn-xs"> <i class="fa fa-user">
                                                   </i> <i class="fa fa-comments-o"></i> 
                                                   </button>-->
                                                   <a href="view_result1.php?aid=<?php echo $r4['id']; ?>&tid=<?php echo $tid; ?>&dept=<?php echo $dept; ?>&qid1=<?php echo $qid; ?>&regno1=<?php echo $r41['regno']; ?>&fname=<?php echo $r4['filename']; ?>&regno=<?php echo $regno; ?>" class="btn btn-primary btn-xs">
                                                   <i class="fa fa-user"> </i> View Code
                                                   </a>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
		<?php
	}
	?></div></div><?php
}
									  //////////////////
									  ?>
									  <br>
									  <hr>
									  <?php
								}
								}
								}
								?>
											</form>
											
									</div>
                                 </div>
                                
                              </div>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="dash_blog">
                              <div class="dash_blog_inner">
                                 <div class="dash_head">
                                    <h3><span><i class="fa fa-comments-o"></i> Program</span></h3>
                                 </div>
                                 <div class="list_cont">
                                    <p>
									
									<?php
									if($aid!="" && $fname!="")
									{
									echo "".$regno1.": ";
									$q52=mysqli_query($connect,"select * from vir_question where id=$qid1");
									$r52=mysqli_fetch_array($q52);
									echo "<br>".$r52['language']." - ".$r52['question'];
									}
									else
									{
									echo "Code";
									}
									?>
									</p>
                                 </div>
                                 <div class="msg_list_main">
                                    <ul class="msg_list">
									
									<form name="form1" class="contact-form" method="post">
								<?php
								if($aid!="" && $fname!="")
								{
								$fn="test/$regno1/$fname";
								$xn=file("$fn");
									foreach($xn as $xnn)
									{
									$cc.=$xnn;
									}
									
									$code=$cc;	
									?><textarea name="ccode2" placeholder="See Result" class="txtarea"><?php  echo $code; ?></textarea><?php
								}
								?>
							</form>
									
                                    </ul>
                                 </div>
                                 <!--<div class="read_more">
                                    <div class="center"><a class="main_bt read_bt" href="#">Read More</a></div>
                                 </div>-->
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <!-- footer -->
                  <div class="container-fluid">
                     <div class="footer">
                        <p>Virtual Lab
                            <a href="https://themewagon.com/"></a>
                        </p>
                     </div>
                  </div>
               </div>
               <!-- end dashboard inner -->
            </div>
         </div>
      </div>
      <!-- jQuery -->
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <!-- wow animation -->
      <script src="js/animate.js"></script>
      <!-- select country -->
      <script src="js/bootstrap-select.js"></script>
      <!-- owl carousel -->
      <script src="js/owl.carousel.js"></script> 
      <!-- chart js -->
      <script src="js/Chart.min.js"></script>
      <script src="js/Chart.bundle.min.js"></script>
      <script src="js/utils.js"></script>
      <script src="js/analyser.js"></script>
      <!-- nice scrollbar -->
      <script src="js/perfect-scrollbar.min.js"></script>
      <script>
         var ps = new PerfectScrollbar('#sidebar');
      </script>
      <!-- custom js -->
      <script src="js/custom.js"></script>
      <script src="js/chart_custom_style1.js"></script>
   </body>
</html>