import java.util.Scanner;
class LeapYear
{
   public static void main(String[ ] arg)
   {
	int yr=2022;
       if(yr%4==0)
       {
       System.out.print(yr+" is a Leap Year.");
       }
      else
      {
      System.out.print(yr+" is not a Leap Year.");
      }
   }
}