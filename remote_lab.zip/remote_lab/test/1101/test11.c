#include <stdio.h>
int main() {
    int num;
    printf("hai");
  
    return 0;
}