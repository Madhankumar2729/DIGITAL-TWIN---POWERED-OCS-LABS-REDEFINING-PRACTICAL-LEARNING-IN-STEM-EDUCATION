public class product{    
 public static void main(String args[]){    
  int a=15,b=10,c=0;
 c=a*b;
System.out.print("Output: "+c);
}    
}   
