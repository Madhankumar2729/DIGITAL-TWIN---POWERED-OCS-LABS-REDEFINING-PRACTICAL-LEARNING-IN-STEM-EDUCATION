<?php
session_start();
ob_start();
$uname=$_SESSION['uname'];
?>
<html>
<head>
<title>PHP</title>
</head>

<body>
<h3>Sum</h3>
<form name="form1" method="post" action="">
  <input type="text" name="n" value="<?php echo $_POST['n']; ?>">
  <input type="submit" name="btn" value="Submit">
</form>
<?php
if(isset($_POST['n']))
{
$f=1;
$n=$_POST['n'];
	for($i=1;$i<=$n;$i++)
	{
	$f=$f*$i;
	}
	echo "Factorial of $n is ".$f;
$fp=fopen("test/$uname/result.txt","w");

$str=Sum is $n is ".$f;
fwrite($fp,$str);
}
?>
</body>
</html>

