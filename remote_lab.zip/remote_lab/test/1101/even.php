<?php
session_start();
ob_start();
$uname=$_SESSION['uname'];
?>
<html>
<head>
<title>PHP</title>
</head>

<body>
<h3>Odd/Even</h3>
<form name="form1" method="post" action="">
  <input type="text" name="n" value="<?php echo $_POST['n']; ?>">
  <input type="submit" name="btn" value="Submit">
</form>
<?php
function odd($n)
{
if($n%2==0)
{
$str= "$n is Even Number";
//echo $str;
}
else
{
$str= "$n is Odd Number";
//echo $str;
}
return $str;
}
if(isset($_POST['n']))
{
$f=1;
$n=$_POST['n'];

$str=odd($n);
echo $str;
$fp=fopen("test/$uname/result.txt","w");
fwrite($fp,$str);
}
?>
</body>
</html>