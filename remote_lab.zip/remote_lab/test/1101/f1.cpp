#include<iostream>
using namespace std;
int main()
{
cout<<"hello welcome";
cout<<"\ngood";
return 0;
}