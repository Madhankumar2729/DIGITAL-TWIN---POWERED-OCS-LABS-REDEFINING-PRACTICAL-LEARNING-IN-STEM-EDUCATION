<?php
session_start();
ob_start();
$uname=$_SESSION['uname'];
?>
<html>
<head>
<title>PHP</title>
</head>

<body>
<h3>Sum of N Numbers</h3>
<?php
$arr=array(150,80,30,40);

?>
<form name="form1" method="post" action="">
 
  <input type="submit" name="btn" value="Sum">
</form>
<?php
if(isset($_POST['btn']))
{
$s=0;
	for($i=0;$i<4;$i++)
	{
	$s=$arr[$i]+$s;
	}
	echo "Sum is $s";
$fp=fopen("test/$uname/result.txt","w");

$str="Sum is $s";
fwrite($fp,$str);
}
?>
</body>
</html>