#include <stdio.h>
int main() {
    int num,s=0;
    //printf("Enter an integer: ");
   // scanf("%d", &num);
num=5;
   for(i=0;i<num;i++)
{
s=s+i;
}
printf("Sum = %d",s);
    return 0;
}